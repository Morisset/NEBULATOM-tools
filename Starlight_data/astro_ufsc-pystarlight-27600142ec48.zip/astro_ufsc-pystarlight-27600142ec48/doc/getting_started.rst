========================
Obtaining and Installing
========================

Requirements
============

numpy, scipy and `atpy <http://atpy.github.com>`_ (Astronomy Tables).

Stable version
==============

The stable version of PySTARLIGHT is `0.3.4 <https://bitbucket.org/astro_ufsc/pystarlight/get/PySTARLIGHT-0.3.4.tar.gz>`.
Install using these commands:

    tar xvzf PySTARLIGHT-X.X.X.tar.gz
    cd PySTARLIGHT-X.X.X/
    python setup.py install
    
The package is also in the python package index, you may install it
using easy_install or pip

	pip install PySTARLIGHT
	
or

	easy_install PySTARLIGHT
	
    
Developer version
=================

Development version (may be broken):

    hg clone https://bitbucket.org/astro_ufsc/pystarlight
   
which can then be installed with::

    cd pystarlight
    python setup.py install
