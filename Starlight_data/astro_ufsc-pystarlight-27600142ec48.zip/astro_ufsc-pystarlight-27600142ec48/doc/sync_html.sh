make html
chmod a+x _build/
chmod -R a+r _build/
rsync -av --delete _build/html/ william@www.iaa.es:public_html/pystarlight_doc/
rsync -av --delete _build/html/ william@acrux.astro.ufsc.br:/var/www/www.starlight.ufsc.br/pystarlight/
