``Maps of Dust IR Emission for Use in Estimation of Reddening and CMBR Foregrounds''
by D.J. Schlegel, D.P. Finkbeiner, & M. Davis, ApJ, 500, 525 (20 June 1998)

Dust maps downloaded from: http://www.astro.princeton.edu/~schlegel/dust/

William @ UFSC - 20/09/2012