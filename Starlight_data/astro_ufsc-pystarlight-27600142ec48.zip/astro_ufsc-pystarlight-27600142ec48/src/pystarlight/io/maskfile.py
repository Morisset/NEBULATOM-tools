'''
Created on 04/04/2013

@author: lacerda
'''

import os

def read(self, maskfile):
    '''
        Reads StarlightChains_v04.for maskfile
        @param maskfile: Starlight input maskfile.
    '''
    self.reset()

    if not os.path.exists(maskfile):
        raise Exception('File not found: %s' % maskfile)

    with open(maskfile) as f:
        data = f.read().splitlines()
        N = int(data[0])
        linedata = [line.split() for line in data[1:N + 1]]
        l_low = []
        l_upp = []
        weight = []
        name = []
        for cols in linedata:
            l_low.append(float(cols[0]))
            l_upp.append(float(cols[1]))
            weight.append(float(cols[2]))
            name.append(' '.join(cols[3:]))
            
        self.table_name = 'maskfile'
        self.add_column('l_low', l_low)
        self.add_column('l_up', l_upp)
        self.add_column('weight', weight)
        self.add_column('name', name)
