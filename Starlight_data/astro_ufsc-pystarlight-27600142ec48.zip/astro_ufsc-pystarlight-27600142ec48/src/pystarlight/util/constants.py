'''
Created on Jun 18, 2012

@author: william
'''

'''
    Simple package with some useful astrophysical constants.
    All the constants are in CGS unit system.
    Usage example: from pystarlight.utils.constants import d_sun 
'''

'''
lacerda@ufsc

Maybe we can use scipy.constants.physical_constants

    from scipy import constants as C 

    m_cm = 1e2
    J_erg = 1e7

    #Speed of light in vacuum
    c = C.physical_constants['speed of light in vacuum'][0] * m_cm
    
    #Planck constant 
    h = C.constants.physical_constants['Planck constant'][0] * J_erg
    
    (...) etc.
'''

d_sun = 1.496e13            # Sun distance: cm
L_sun = 3.826e33            # Sun bolometric luminosity: ergs/s
M_sun = 1.9891e33           # Solar mass: g 
Mpc_cm = 3.085677581e24     # One Megaparsec in cm
h = 6.6260755e-27           # Planck constant: erg s
c = 2.99792458e10           # Speed of light in vacuum: cm / s
yr_sec = 3.15569e7          # One year in seconds
