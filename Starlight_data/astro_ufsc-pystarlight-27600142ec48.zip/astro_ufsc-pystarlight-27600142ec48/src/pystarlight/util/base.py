'''
Created on 30/05/2014

@author: andre
         
Update on 10/07/2014 by lacerda@Saco
    Added StarlightBase support for hdf5 files.
'''

import pystarlight.io  # @UnusedImport
import h5py
import atpy
import numpy as np
from os import path
from .StarlightUtils import bin_edges, hist_resample

###############################################################################

def base_mask(met_base, age_base):
    ages = np.unique(age_base)
    metals = np.unique(met_base)
    base_mask = np.zeros((len(metals), len(ages)), dtype='bool')
    for Z, a in zip(met_base, age_base):
        i = np.where(metals == Z)[0]
        j = np.where(ages == a)[0]
        base_mask[i, j] = True
    return base_mask

###############################################################################

################################################################################

def update_dataset(grp, name, data):
    '''
    Wrapper for adding or updating a dataset with new data.
    '''
    ds = grp.require_dataset(name, data.shape, data.dtype, compression='gzip', compression_opts=4)
    ds[:] = data
    return ds

################################################################################

################################################################################

def add_base_group(f, base, group):
    g = f.require_group(group)
    update_dataset(g, 'f_ssp', base.f_ssp)
    update_dataset(g, 'Mstars', base.Mstars)
    update_dataset(g, 'sspfile', base.sspfile)
    update_dataset(g, 'YA_V', base.YA_V)
    update_dataset(g, 'aFe', base.aFe)
    update_dataset(g, 'age_base', base.ageBase)
    update_dataset(g, 'Z_base', base.metBase)
    update_dataset(g, 'wl', base.l_ssp)
    update_dataset(g, 'baseMask', base.baseMask)
    
################################################################################

class StarlightBase(object):
    '''
    Starlight base interface and utilities.
    
    Parameters
    ----------
    base_file : string
        Is the base is in ASCII, this is the file describing the base. 
        This is the one specified in the starlight grid file. 
        If the base is in hdf5, base_file is the path to hdf5 base file name 
        and if the file extension is .h5 or .hdf5, hdf5 is set to True 
        automatically.   
        
    base_storage : string
        If base_file is an ASCII file, base_storage is the directory 
        containing the base spectra.
        If base_file is a hdf5 file, base_storage is used as base group 
        (folder) in the hdf5 file. If not setted, base group will be 
        path.basename(base_file).
        
    hdf5 : True or False : default = False
        If True assumes base_file as a hdf5 file. 
            
    Examples
    --------
    TODO: examples
    '''

    def __init__(self, base_file=None, base_storage=None, hdf5=False):
        if base_file:
            ext = base_file.split('.')[-1]
            if ext == 'h5' or ext == 'h5py':
                hdf5 = True
                
            if not hdf5:
                self.load_ascii(base_file, base_storage)
            else:
                self.load_hdf5(base_file, base_storage)
        #else:
        #    DO SOMETHING


    def load_ascii(self, base_file, base_dir):
        btable = atpy.Table(base_file, type='starlightv4_base', basedir=base_dir, read_basedir=True)
        self.ageBase = np.unique(btable.age_base)
        self.metBase = np.unique(btable.Z_base)
        self.nAges = len(self.ageBase)
        self.nMet = len(self.metBase)
        self.baseMask = base_mask(btable.Z_base, btable.age_base)
        
        self.l_ssp = btable.l_ssp[0]
        if (btable.l_ssp != self.l_ssp).any():
            raise Exception('ASCII base is not well defined on all elements in wavelength.')
        
        self.nWavelength = len(self.l_ssp)
        self.f_ssp = self._reshape(btable.f_ssp)
        self.Mstars = self._reshape(btable.Mstars)
        self.sspfile = self._reshape(btable.sspfile)
        self.YA_V = self._reshape(btable.YA_V)
        self.aFe = self._reshape(btable.aFe)
        
        
    def load_hdf5(self, base_file, base_str):
        if not base_str:
            base_str = path.basename(base_file)
        try:
            with h5py.File(base_file, mode='r') as f:
                # The datasets are stored in "folders" (called groups
                # in the HDF5 jargon) with the same name as the base.
                # This is how we get this group, to ease the gets for
                # the datasets below.
                base = f[base_str]
                self.ageBase = base['age_base'].value
                self.metBase = base['Z_base'].value
                self.l_ssp = base['wl'].value
                self.nAges = len(self.ageBase)
                self.nMet = len(self.metBase)
                self.baseMask = base['baseMask'].value
        
                self.f_ssp = self._mask(base['f_ssp'].value)
                self.Mstars = self._mask(base['Mstars'].value)
                self.sspfile = self._mask(base['sspfile'].value)
                self.YA_V = self._mask(base['YA_V'].value)
                self.aFe = self._mask(base['aFe'].value)
        except:
            raise Exception('Could not open HDF5 base %s[%s].' % (base_file, base_str))
             
                
    def f_sspResam(self, l_obs_resam):
        bins_orig = bin_edges(self.l_ssp)
        bins_resam = bin_edges(l_obs_resam)
        f_ssp_resam = np.ma.masked_all((self.nMet, self.nAges, len(l_obs_resam)))
        f_ssp_resam.fill_value = 0
        
        for t in xrange(self.nAges):
            for Z in xrange(self.nMet):
                if not self.baseMask[Z,t]: continue
                f_ssp_resam[Z,t] = hist_resample(bins_orig, bins_resam, self.f_ssp[Z,t], density=True) 
        return f_ssp_resam

    
    def _reshape(self, a, fill_value=0.0):
        '''
        Convert an array from 1-D j-notation to 2-D (Z, age)-notation.
        The first dimesion must be j.
        '''
        shape = (self.nMet, self.nAges) + a.shape[1:]
        a__Zt = np.ma.masked_all(shape, dtype=a.dtype)
        a__Zt.fill_value = fill_value
        a__Zt[self.baseMask, ...] = a
        return a__Zt
        
    def _mask(self, a, fill_value=0.0):
        a__Zt = np.ma.masked_array(a, dtype=a.dtype)
        a__Zt[~self.baseMask] = np.ma.masked
        a__Zt.fill_value = fill_value
        return a__Zt
    
    
    def write_hdf5(self, output_file, base_group, overwrite=False):
        '''
        Writes a previously read base to a hdf5 file.
        
        Parameters
        ----------
        
        output_file : string
            Output hdf5 file name. 

        base_group : string
            Group folder to receive the base.
            
        overwrite : True or False : default = False
            Overwrites a base if one uses the same group name.
            
        Examples
        --------
        TODO: examples.
        '''
        
        with h5py.File(output_file, 'a') as f:
            if not overwrite and base_group in f:
                raise Exception('Group %s already exists. Use overwrite=True' % base_group)
            
            add_base_group(f, self, base_group)

                    
    def getLookbacktimeSpectraOperator(self, evoBase__T, wavelength=None):
        '''
        FIXME: This is broken!
        
        Returns an operator for computing spectra in lookbacktime.
        If wavelength is None, use the base wavelength array.
        
        Examples
        ========
        evoBase__T = 10.0**np.arange(8, 10, 0.1) # log_10 steps
        mini__tZ = (popmu_ini__tZ * Mini_tot / 100.0)
        f_ssp__TtZl = base.getLookbacktimeSpectraOperator(evoBase__T)
        F__Tl = np.tensordot(f_ssp__TtZl, mini__tZ, [(1, 2), (0, 1)])
        
        # plot all the spectra.
        plt.figure()
        for i, age in enumerate(evoBase__T):
            plt.plot(base.l_ssp__l, F__Tl[i], label=age)
        plt.legend()
        plt.show()
        '''
        if wavelength is None:
            wavelength = self.l_ssp
        interpolated_f_ssp = self.f_sspResam(wavelength)
        interpolated_f_ssp = np.ma.array(interpolated_f_ssp, copy=False)
        interpolated_f_ssp[~self.baseMask,:] = np.ma.masked
        lbto = np.ma.masked_all((len(evoBase__T), self.nMet, self.nAges, len(wavelength)))
        for i, T in enumerate(evoBase__T):
            mask = self.ageBase >= T
            sel = np.digitize(self.ageBase[mask] - T, self.ageBase)
            lbto[i, :, mask,:] = interpolated_f_ssp[:,sel,:]
        return lbto


