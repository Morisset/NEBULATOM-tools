'''
Created on 13/Oct/2014, taken from specHelper.py

@author: Natalia Vale Asari

Model a spec. Right now it only models it as a sum of gaussians (for emission lines.)
'''

import os
from copy import copy, deepcopy

import matplotlib.pyplot as plt
import numpy as np
import atpy

import specHelpers as specH

# Physical constants
c_light = 299792.458  # km/s


class SpecModel(object):
    '''
    Modeling a spec as a sum of several components (only tested for Spec0D so far)
    '''

    def __init__(self, s0d_obs, s0d_syn, smooth = None):
        self.fobs = s0d_obs
        self.cont = s0d_syn                # Synthetic continuum to get equivalent widths from

        if (smooth is None):
            self.smoothdata = deepcopy(self.fobs)
            self.smoothdata._spec__ld *= 0.
        else:
            self.smoothdata = smooth

        self.data = self.fobs - self.cont - self.smoothdata  # Spec instance to fit

        self.fsyn = self.cont
        self.fres = self.data

        self.cont.normalize_spec('lrest', 5590., 5680.)
        self.data.normalize_spec('lrest', 5590., 5680., normalize_by = self.cont.fnorm)

        self.base = deepcopy(self.fobs)
        self.base._spec__ld *= 0.

        
    def copy(self):
        return self.__class__(self.fobs, self.fsyn, smooth=self.smoothdata)

    
    def rectify_spec(self, rms_lim = 1., debug = False):

        data = deepcopy(self.data)
        
        # Initial paramters
        diff = data
        rms = np.std(diff._spec__ld)

        for i in np.arange(1, 3):

            if i == 1: rms_lim = 1.0 * rms_lim
            if i  > 1: rms_lim = 1.0 * rms_lim
                
            # Flag emission lines; note I extend the flags a bit
            flag_lines = np.abs(diff._spec__ld) >= (rms * rms_lim)
            flag_lines = flag_lines | np.append(flag_lines[1:], [0])
            flag_lines = flag_lines | np.append([0], flag_lines[:-1])
            data.add_flagType(flag_lines, flagType_id = 'emlines', flagType_value = 1)

            # Get local rms -- trick to get better at chopping wings of emission lines for next iteration
            meddata = diff.boxFilter_lambda(100, flag = True)
            rmsdata = meddata - diff
            rmslocal = rmsdata.boxFilter_lambda(30, flag = True)
            rms = np.abs(rmslocal._spec__ld)
            
            # Smooth spec
            smoothdata = data.gaussianFilter_lambda(15, flag = True)

            # Save new diff spec
            diff = data - smoothdata

            if debug:
              if i > 1: 
                data.plot(color_spec = "black")
                smoothdata.plot(color_spec = "purple")
                diff.plot(color_spec = "green")
                plt.fill_between(data.lrest, -rms * rms_lim, rms * rms_lim, alpha = 0.5)
                plt.axhline(0.)
                #plt.plot(self.data.lrest, flag_lines)

        self.smoothdata = smoothdata
        self.data._spec__ld[:] = diff._spec__ld

        if debug:
            orig = self.data + self.smoothdata
            orig.plot(color_spec = "blue")

    def add_noise_to_data(self, sd):

        from scipy.stats import norm
        
        # norm.rvs: The scale (scale) keyword specifies the standard deviation.
        Ntot = self.data.Nl * self.data.Npix
        aux__ld = norm.rvs(size=Ntot, scale=sd)
        N__ld = self.data.repackPixelDimensions(aux__ld)

        # Add noise
        newModel = self.copy()
        newModel.data._spec__ld += N__ld

        return newModel

    
    def mc_uncertainties(self, sd, Nruns = 10,
                         outfile = None, append = True, overwrite = False,
                         debug = False):
        '''
        Uncertainties from Monte Carlo realizations.
        '''

        # File to save to
        outfile = test_file(outfile, default='/tmp/lix.hdf5', append=(not overwrite), delete=overwrite, debug=debug)

        # Read old file if we are going to append it
        elines = []
        if (append) & (os.path.exists(outfile)):
            elines = specH.read_lines_params_hdf5_dataset(outfile)
            outfile = test_file(outfile, default='/tmp/lix.hdf5', append=False, delete=True, debug=debug)
            
        # Open hdf5 file
        f = h5py.File(outfile, "w")

        # Save old runs in file
        ilow = 0
        if (append):
            if (len(elines) > 0):
                for key, value in elines.items():
                    ds = f.create_dataset(key, data = value, compression = 'gzip', compression_opts = 4)
                    ilow = max(ilow, int(key) + 1)
                    
        for irun in range(ilow, ilow+Nruns+1):

            # Add noise & refit
            newModel = self.add_noise_to_data(sd)
            newModel.fit_emis_lines_gauss_l()

            newModel.save_summary_to_hdf5_dataset(f, '%05i' % irun)

            # Save
            if debug:
                plt.figure(2)
                plt.clf()
                self.data.plot(color_spec = "blue")
                newModel.data.plot(color_spec = "green")
                self.plot_gaussians(color_spec = "cyan")
                newModel.plot_gaussians(color_spec = "yellow")

        f.close()
        
                
    def simple_uncertainties(self, sd, addnoise = False, 
                             outfile = None, overwrite = False,
                             debug = False):
        '''
        Uncertainties from simple `by hand' measurements.
        '''
    
        # Add noise (or not)
        if addnoise:
            newModel = self.add_noise_to_data(sd)
        else:
            newModel = self.copy()

        # File to save to
        outfile = test_file(outfile, default='/tmp/lix.hdf5', delete=overwrite, debug=debug)

        # Open hdf5 file
        f = h5py.File(outfile, "w")
            
        # Refit with new baseline
        for base in [-sd, sd]:
            newModel.fit_emis_lines_gauss_l(F0 = base)

            # Save
            newModel.save_summary_to_hdf5_dataset(f, 'std=%7.4f' % base)
    
            if debug:
                plt.figure(2)
                plt.clf()
                self.data.plot(color_spec = "blue")
                newModel.data.plot(color_spec = "green")
                self.plot_gaussians(color_spec = "cyan")
                newModel.plot_gaussians(color_spec = "yellow")
                print 'Press enter for next plot'
                raw_input()

        f.close()


    def save_summary_to_hdf5_dataset(self, f_h5py, name):
        '''
        f_h5py must be an open h5py file.
        '''
        elines, fmt, footer = self.summary_elines()
        ds = f_h5py.create_dataset(name, data = elines, compression = 'gzip', compression_opts = 4)
        

    def fit_emis_lines_gauss_l(self, lines_file = None, baseline = 'resid', F0 = 0., refit_all = False):

        # Create dictionary for all lines
        self.El_gauss_l = {}

        # Read line table
        self.lines_params = specH.read_lines_params(lines_file)
        #self.lines_params = self.lines_params.rows([9, 10, 11])

        # Define if we want to calc the baseline or not
        if (baseline == 'resid'):
            F0_status = 'fixed'
        elif (baseline == 'cont'):
            F0_status = 'fixed'
        else:
            F0_status = 'limited'

        # Create lines with first guesses
        for line_params in self.lines_params:

            ll_blue_cont = (line_params[2], line_params[3])
            ll_red_cont  = (line_params[4], line_params[5]) 
            cont, cerror = self.measure_cont(ll_blue_cont, ll_red_cont, baseline)
            if (baseline == 'cont'): F0 = cont

            aux = LineModel(data = self.data, fit_type = "gauss_l",
                            l_centre = line_params[1], 
                            ll_blue_cont = ll_blue_cont,
                            ll_red_cont  = ll_red_cont,
                            F0_status = F0_status, F0 = F0,
                            basespec = self.base
                            )

            self.El_gauss_l[line_params[0]] = aux
            self.El_gauss_l[line_params[0]].cont = cont
            self.El_gauss_l[line_params[0]].cerror = cerror

        # Refit blended lines:
        # [NII], Ha
        # [SII]
        # [SIII]6312, [OI]6300
        self.blended_groups = [ ['[NII]6548', 'Halpha', '[NII]6584'],
                                ['[SII]6716', '[SII]6731'],
                                ['[SIII]6312', '[OI]6300'] ]
        
        for blended in self.blended_groups:
            # Changed below to be compatible with python 2.6 @ alphacrucis.
            # Try to get back to more elegant notation asap.
            #refit = {k: self.El_gauss_l[k] for k in blended}
            refit = dict((k, self.El_gauss_l[k]) for k in blended)
            El_gauss_sum_l = LinesModel(self.data, refit, F0_status = F0_status, basespec = self.base)

        # Refit everything --- takes a long time!
        if refit_all:
            self.El_gauss_sum_l = LinesModel(self.data, self.El_gauss_l)

            
    def measure_cont(self, ll_blue_cont, ll_red_cont, baseline = 'resid'):
        
        cont = -999.
        cerror = -999.
            
        flag_cont_blue = (self.cont.lrest >= ll_blue_cont[0]) & (self.cont.lrest <= ll_blue_cont[1])
        flag_cont_red  = (self.cont.lrest >= ll_red_cont[0])  & (self.cont.lrest <= ll_red_cont[1])
        flag_cont = flag_cont_blue | flag_cont_red

        if (sum(flag_cont) > 1):
            spec_cont = self.cont._spec__ld[flag_cont]
            spec_cont_err = self.data._spec__ld[flag_cont]
            
            cont = np.median(spec_cont)
            cerror = np.std(spec_cont_err)

        if np.isnan(cont): cont = -999.
        if np.isnan(cerror): cerror = -999.

        if (baseline == 'cont'):
            ff = (self.cont.lrest >= ll_blue_cont[0]) & (self.cont.lrest <= ll_red_cont[1])
            self.base._spec__ld[ff] = cont
            
        return cont, cerror
    
    def plot_gaussians(self, color_spec = 'black', linestyle = '-', x = None):
        if x == None:
            x = self.data.lrest
        params = np.array([ line_model.params for line_name, line_model in self.El_gauss_l.items() ]).flatten()
        G = specH.gaussian_sum_l(x, params)
        #G += self.base._spec__ld
        plt.plot(x, G, color = color_spec, linestyle = linestyle)

        
    def calc_flux_integrated_all(self, spec = None, large_window = False, debug = False):

        if spec == 'fres':
            s0d = self.data
        elif spec == 'fobs':
            s0d = self.fobs
        elif spec == 'fsyn':
            s0d = self.fsyn
        
        if debug:
            s0d.plot(color_spec = "red")

        for line_name, line_model in self.El_gauss_l.items():
            params = deepcopy(line_model.params)
            intF, intC  = self._calc_flux_integrated(s0d, line_name, params, large_window = large_window, debug = debug)
            self.El_gauss_l[line_name].intF = intF
            self.El_gauss_l[line_name].intC = intC

            
        for ib, blended in enumerate(self.blended_groups):
            
            params = np.array([self.El_gauss_l[line_name].params for line_name in blended]).flatten()
            intF, intC  = self._calc_flux_integrated(s0d, 'blended%s' % ib, params, large_window = large_window, debug = debug)

            lcen = np.array([self.El_gauss_l[line_name].params[0] for line_name in blended]).flatten()
            ind = np.argsort(lcen)
            lines_sorted = np.array(blended)[ind]
            Nlines = len(lines_sorted)
            
            int_blended = 0.
            for i, line_name in enumerate(lines_sorted):
                # Define flux as measured by gaussian to all blended lines, except the central or red-most
                self.El_gauss_l[line_name].intF = self.El_gauss_l[line_name].params[1]
                self.El_gauss_l[line_name].intC = intC
                s0d.intF[line_name] = self.El_gauss_l[line_name].intF
                if (i != 1):
                    int_blended += self.El_gauss_l[line_name].intF

            # Save flux for central or red-most line
            self.El_gauss_l[lines_sorted[1]].intF = intF - int_blended
            s0d.intF[lines_sorted[1]] = self.El_gauss_l[lines_sorted[1]].intF

            if debug:
                print blended, intF

            
        if debug:
            for line_name, line_model in self.El_gauss_l.items():
                print line_name, 'int: ', line_model.intF, line_model.intC, line_model.intF/line_model.intC       
                print      '    gau:', line_model.params[1], line_model.cont, line_model.params[1] / line_model.cont

            
    def _calc_flux_integrated(self, s0d, line_name, params, cont_l = 10., large_window = False, debug = False):

        # Get gaussians
        l = s0d.lrest
        dl = l[1] - l[0]
        G = gaussian_sum_l(l, params)
        EWpars = {}

        # Now select the central window from the gaussians
        l_centre = params[0]
        f_line = (G > 5.e-3) | (abs(l - l_centre) < dl)

        if f_line.sum() == 0:
            ll_window = (l_centre-1., l_centre+1.)
        else:
            ind_f_line = np.where(f_line)[0]
            ll_window = (l[ind_f_line[0]], l[ind_f_line[-1]])

        ll_blue_cont = (ll_window[0] - cont_l, ll_window[0])
        ll_red_cont  = (ll_window[1], ll_window[1] + cont_l) 
        
        EWpars[line_name] = l_centre, ll_window, ll_blue_cont, ll_red_cont
            
        s0d.measureEW(EWpars = EWpars, large_window = large_window, debug = debug)

        return s0d.intF[line_name], s0d.intC[line_name]

    
    def summary_elines(self):
        '''
        Save emission line info to an easy-to-use array.
        '''

        # Old & wrong way commented out.
        # The trick below saves things in the same order as the input line list.
        #El_l = np.array([ line_model.params[0] for line_name, line_model in self.El_gauss_l.iteritems() ])

        line_names = self.lines_params['col1']
        line_models = np.array([ self.El_gauss_l[line_name] for line_name in line_names ])

        El_l  = np.array([ line_model.params[0] for line_model in line_models ])
        El_F  = np.array([ line_model.params[1] for line_model in line_models ]) * self.cont.fnorm * self.cont.fobs_norm
        El_v0 = np.array([ line_model.params[2] for line_model in line_models ])
        El_vd = np.array([ line_model.params[3] for line_model in line_models ])
        El_Cl = np.array([ line_model.params[4] for line_model in line_models ]) * self.cont.fnorm * self.cont.fobs_norm
        
        El_F_e  = np.array([ line_model.perror[1] for line_model in line_models ]) * self.cont.fnorm * self.cont.fobs_norm
        El_v0_e = np.array([ line_model.perror[2] for line_model in line_models ])
        El_vd_e = np.array([ line_model.perror[3] for line_model in line_models ])
        El_Cl_e = np.array([ line_model.perror[4] for line_model in line_models ]) * self.cont.fnorm * self.cont.fobs_norm
        
        El_chi2 = np.array([ line_model.m.fnorm for line_model in line_models ])
        
        El_C   = np.array([ line_model.cont   for line_model in line_models ]) * self.cont.fnorm * self.cont.fobs_norm
        El_C_e = np.array([ line_model.cerror for line_model in line_models ]) * self.cont.fnorm * self.cont.fobs_norm
        
        El_W   = specH.safe_div(El_F, El_C)
        El_W_e = specH.safe_div(El_F_e, El_C) + El_C_e * specH.safe_div(El_W, El_C)
        
        El_SN = specH.safe_div(El_F, El_F_e)

        
        # Clean nan's and inf's
        m = (lambda x: specH.replace_nan_inf_by_minus999(x))
        Els   = zip(m(El_l), m(El_F), m(El_F_e), m(El_W), m(El_W_e), m(El_vd), m(El_vd_e), m(El_v0), m(El_v0_e), m(El_SN), m(El_C), m(El_C_e), m(El_chi2), m(El_Cl), m(El_Cl_e))
        names   = ["lambda",  "El_F",  "El_F_e",  "El_W",  "El_W_e",  "El_vd",  "El_vd_e",  "El_v0",  "El_v0_e",  "El_SN",  "El_C",  "El_C_e",   "chisqr",  "El_Cl",  "El_Cl_e"]
        formats = ['float64' for i in xrange(len(names))]
        elines = np.array(Els, dtype={'names': names, 'formats': formats})

        fmt = "%8.3f " + ' '.join(['%12.4e' for i in xrange(len(names)-1)])
        footer = '# ' + names[0] + ''.join(['%13s' % name for name in names[1:]]) + '\n'
        
        return elines, fmt, footer
    
        
class LineModel(object):
    '''
    Modeling one line as a function --- only gaussian implemented so far
    '''

    def __init__(self, data, fit_type, 
                 l_centre, ll_blue_cont, ll_red_cont,
                 v0_min = -200., v0_max = 200., 
                 vd_min = 0.,    vd_max = 500.,
                 v0 = 0.,   v0_status  = 'limited',
                 vd = 100., vd_status  = 'limited',
                 F  = 1.,    F_status  = 'limited',
                 F0 = 0.,    F0_status = 'fixed',
                 basespec = None
                 ):

        # Spec instance to fit
        self.data     = data  

        if (basespec is not None):
            self.data = data - basespec
            
        # Type of fit: gaussian, voigt, etc
        self.fit_type = fit_type

        # Line parameters: centre, blue and red continua
        self.l_centre     = l_centre      
        self.ll_blue_cont = ll_blue_cont       
        self.ll_red_cont  = ll_red_cont  

        # Calc local continuum baseline with ll_blue_cont and ll_red_cont
        self.calc_baseline()

        # Limits for v0 and vd
        self.v0_min = v0_min
        self.v0_max = v0_max
        self.vd_min = vd_min
        self.vd_max = vd_max

        # First guesses or fixed v0, vd, F, F0 (baseline)
        self.v0 = v0
        self.vd = vd
        self.F  = F
        self.F0 = F0

        # Status = limited (free), fixed, tied (constrained by other lines)
        # TO DO properly; this is only being used for the F0 baseline
        self.v0_status = v0_status
        self.vd_status = vd_status
        self.F_status  = F_status
        self.F0_status = F0_status

        # Fit gaussian
        if (fit_type == "gauss_l"):
            self.fit_gauss_l()
        
    def calc_baseline(self):
        pass

    def fit_gauss_l(self):
        from mpfit import mpfit

        import copy

        # Transform v --> l
        lref = 7000.
        self.v0_min = (lref / c_light) * self.v0_min
        self.v0_max = (lref / c_light) * self.v0_max
        self.vd_min = (lref / c_light) * self.vd_min
        self.vd_max = (lref / c_light) * self.vd_max
        self.v0     = (lref / c_light) * self.v0
        self.vd     = (lref / c_light) * self.vd

        # Get all parameters first guesses into one array
        par_init = [self.l_centre, self.F, self.v0, self.vd, self.F0,]
        # self.b_F, self.b_v0, self.b_vd] # broad components

        # Populate the configurations for each parameter
        par_info = [{'value': 0., 'fixed': 0, 'limited': [0, 0], 'limits' : [0., 0.], 'tied' : ''}
 												for i in range(len(par_init))]

        par_info[0]['fixed'  ] = 1
        par_info[1]['limited'] = [1, 0]
        par_info[1]['limits' ] = [0, 0]
        par_info[2]['limited'] = [1, 1]
        par_info[2]['limits' ] = [self.v0_min, self.v0_max]
        par_info[3]['limited'] = [1, 1]
        par_info[3]['limits' ] = [self.vd_min, self.vd_max]
        par_info[4]['fixed'  ] = 1

        # Calc baseline
        if (self.F0_status != 'fixed'):
            par_init[4] = self.F
            par_info[4]['fixed'  ] = 0
            par_info[4]['limited'] = [1, 1]
            par_info[4]['limits' ] = [-1, 5]

        data_fit = { 'x' : self.data.lrest, 
                     'y' : self.data._spec__ld, 
                     'err' : self.data._erro__ld }

        self.m = mpfit(self.mpfit_gaussian_l, par_init, parinfo = par_info, functkw = data_fit, quiet = 1)

        if (self.m.perror is None):
            self.m.perror = np.zeros_like(self.m.params) -999.

        self.params = self.m.params
        self.perror = self.m.perror

        #G = gaussian_sum_l(self.data.lrest, self.params)
        #plt.plot(self.data.lrest, G)
        #print self.params[0], self.params[2], self.params[3], self.params[4]

        
    def fit_gauss_v(self):
        pass


    def mpfit_gaussian_l(self, p, fjac = None, x = None, y = None, err = None):

        # Fix error == 0
        if (y != None) & (err != None):
            err = np.where(err == 0., 0.1*y, err)

        # If fjac==None then partial derivatives should not be
        # computed.  It will always be None if MPFIT is called with default
        # flag.
        model = specH.gaussian_l(x, p)

        # Non-negative status value means MPFIT should continue, negative means
        # stop the calculation.
        status = 0

        return [status, (y-model)/err]


class LinesModel(object):
    '''
    Modeling several lines
    '''

    def __init__(self, data, dict_LineModel, 
                 F0_status = 'fixed',
                 basespec = None):

        self.data = data
        self.lines = dict_LineModel
        if (basespec is not None):
            self.data = data - basespec

        self.F0_status = F0_status

        # Fit gaussians
        self.fit_gauss_sum_l()


    def fit_gauss_sum_l(self):
        from mpfit import mpfit
        import copy

        # Get all parameters first guesses into one array
        par_init = np.array([ line_model.params for line_name, line_model in self.lines.iteritems() ]).flatten()

        # Populate the configurations for each parameter
        par_info = [{'value': 0., 'fixed': 0, 'limited': [0, 0], 'limits' : [0., 0.], 'tied' : ''}
 												for i in range(len(par_init))]

        i_NII6548 = None
        i_NII6584 = None
        n = 5

        for i, line_name in enumerate(self.lines):

            line_model = self.lines[line_name]

            # Line center
            par_info[0+n*i]['fixed'  ] = 1

            # Flux
            par_info[1+n*i]['limited'] = [1, 0]
            par_info[1+n*i]['limits' ] = [0, 0]

            # v0
            par_info[2+n*i]['limited'] = [1, 1]
            par_info[2+n*i]['limits' ] = [line_model.v0_min, line_model.v0_max]

            # vd
            par_info[3+n*i]['limited'] = [1, 1]
            par_info[3+n*i]['limits' ] = [line_model.vd_min, line_model.vd_max]

            # Baseline
            par_info[4+n*i]['fixed'  ] = 1
            if (self.F0_status != 'fixed'):
                if (i == 0):
                    par_info[4+n*i]['fixed'  ] = 0
                    par_info[4+n*i]['limited'] = [1, 1]
                    par_info[4+n*i]['limits' ] = [-1, 5]
                    par_init[4+n*i] =  0.
                else:
                    par_info[4+n*i]['tied'] = 'p[4]'
            
            # Save lines to be tied
            if (line_name == '[NII]6548'): i_NII6548 = i
            if (line_name == '[NII]6584'): i_NII6584 = i

                
        # Get ties done
        if (i_NII6548 != None) & (i_NII6584 != None):
            # Flux
            #par_info[1+n*i_NII6548]['tied'] = 'p[%s] / 3.' % (1+n*i_NII6584)
            # v0
            par_info[2+n*i_NII6548]['tied'] = 'p[%s]' % (2+n*i_NII6584)
            # vd
            par_info[3+n*i_NII6548]['tied'] = 'p[%s]' % (3+n*i_NII6584)
            
        # Treat baseline here
        data_fit = { 'x' : self.data.lrest, 
                     'y' : self.data._spec__ld,
                     'err' : self.data._erro__ld }

        # Plot
        #plt.clf()
        #G = gaussian_sum_l(self.data.lrest, par_init)
        #plt.plot(self.data.lrest, self.data.spec__l, color = 'k', linestyle = 'steps-mid')
        #plt.plot(self.data.lrest, G, color = 'purple')
        #plt.xlim(6400, 6800)
        #print par_init
        
        #gaussian_sum_l(self.data.lrest, par_init)
        self.m = mpfit(self.mpfit_gaussian_sum_l, par_init, parinfo = par_info, functkw = data_fit, quiet = 1)

        # Plot
        #G = gaussian_sum_l(self.data.lrest, self.m.params)
        #plt.plot(self.data.lrest, G, color = 'red')
        #print self.m.params
        
        if (self.m.perror is None):
            self.m.perror = np.zeros_like(self.m.params) -999.
        
        params__e = self.m.params.reshape(-1, 5)
        perror__e = self.m.perror.reshape(-1, 5)
        
        # Save new parameters to each LineModel
        for i, line_name in enumerate(self.lines):
            self.lines[line_name].params = params__e[i]
            self.lines[line_name].perror = perror__e[i]
            self.lines[line_name].m = self.m

        
    def mpfit_gaussian_sum_l(self, p, fjac = None, x = None, y = None, err = None):
        # If fjac==None then partial derivatives should not be
        # computed.  It will always be None if MPFIT is called with default
        # flag.
        model = specH.gaussian_sum_l(x, p)
        # Non-negative status value means MPFIT should continue, negative means
        # stop the calculation.
        status = 0
        return [status, (y-model)/err]

    
