'''
Created on Jun 27, 2013

@author: andre
'''

import numpy as np

__all__ = ['SpectraVelocityFixer', 'apply_kinematics', 'apply_kinematics_flagged']

################################################################################
class SpectraVelocityFixer(object):
    '''
    FIXME: docme.
    '''
    
    def __init__(self, l_obs, v_0, v_d, nproc=None):
        self.l_obs = np.ascontiguousarray(l_obs, 'float64')
        if not np.allclose(self.l_obs, np.linspace(self.l_obs.min(), self.l_obs.max(), len(self.l_obs))):
            raise ValueError('l_obs is not equally spaced.')
        if np.isscalar(v_0):
            self.v_0 = np.array([v_0])
        else:
            self.v_0 = np.asarray(v_0)
        if np.isscalar(v_d):
            self.v_d = np.array([v_d])
        else:
            self.v_d = np.asarray(v_d)
        self.nproc = nproc
        
        
    def _getVd(self, target_vd):
        m = self.v_d < target_vd
        vd_fix = np.zeros_like(self.v_d)
        vd_fix[m] = np.sqrt(target_vd**2 - self.v_d[m]**2)
        return vd_fix
  
    
    def fixFlagged(self, flux, err, flag, target_vd=0.0, fill='nearest', fill_val=0.0, l_cov_FWHM=-1.0):
        vd = self._getVd(target_vd)
        return apply_kinematics_flagged(self.l_obs, flux, err, flag, -self.v_0, vd, fill, fill_val, l_cov_FWHM, self.nproc)


    def fix(self, flux, target_vd=0.0, fill='nearest', fill_val=0.0):
        vd = self._getVd(target_vd)
        return apply_kinematics(self.l_obs, flux, -self.v_0, vd, fill, fill_val, self.nproc)
################################################################################


################################################################################
def apply_kinematics_flagged(l_obs, flux, err, flag, v_0, v_d, fill='nearest', fill_val=0.0, l_cov_FWHM=-1.0, nproc=None):
    '''
    FIXME: docme.
    '''
    if np.isscalar(v_0):
        v_0 = np.array((v_0,))
    if np.isscalar(v_d):
        v_d = np.array((v_d,))
    shape = (len(l_obs),) + v_0.shape
    one_d = False
    if flux.shape == l_obs.shape:
        one_d = True
        flux = flux[:, np.newaxis]
        err = err[:, np.newaxis]
        flag = flag[:, np.newaxis]
    elif flux.shape != shape:
        raise ValueError('flux has an incorrect shape: %s. Should be %s.' % flux.shape, shape)

    params = _paramsFlagged_iter(l_obs, flux, err, flag, v_0, v_d, fill, fill_val, l_cov_FWHM)
    out = _process(_velocitySmoothFlag_wrapper, params, nproc)

    if one_d:
        flux_s, err_s, flag_s = out[0][0], out[0][1], out[0][2]
    else:
        flux_s = np.empty_like(flux)
        err_s = np.empty_like(err)
        flag_s = np.empty_like(flag)
        for i, z in enumerate(out):
            flux_s[:,i], err_s[:,i], flag_s[:,i] = z[0], z[1], z[2]
    return flux_s, err_s, flag_s
################################################################################


################################################################################
def apply_kinematics(l_obs, flux, v_0, v_d, fill='nearest', fill_val=0.0, nproc=None):
    '''
    FIXME: docme.
    '''
    if np.isscalar(v_0):
        v_0 = np.array((v_0,))
    if np.isscalar(v_d):
        v_d = np.array((v_d,))
    shape = (len(l_obs),) + v_0.shape
    one_d = False
    if flux.shape == l_obs.shape:
        one_d = True
        flux = flux[:, np.newaxis]
    elif flux.shape != shape:
        raise ValueError('flux has an incorrect shape: %s. Should be %s.' % flux.shape, shape)

    params = _params_iter(l_obs, flux, v_0, v_d, fill, fill_val)
    out = _process(_velocitySmooth_wrapper, params, nproc)

    if one_d:
        return out[0]
    else:
        return np.array(out).T
################################################################################


################################################################################
def _process(func, params, nproc=None):
    import multiprocessing
    if nproc is None:
        nproc = multiprocessing.cpu_count()
    if nproc != 1:
        pool = multiprocessing.Pool(nproc)
        out = pool.map(func, params)
        pool.close()
    else:
        out = [func(args) for args in params]
    return out
################################################################################


################################################################################
def _paramsFlagged_iter(l_obs, flux, err, flag, v_0, v_d, fill, fill_val, l_cov_FWHM):
    '''
    Argument factory for :func:`_velocitySmoothFlag_wrapper`.
    '''
    if flux.ndim == 1:
        N_spec = 1
    else:
        N_spec = flux.shape[1]
    for i in xrange(N_spec):
        yield (l_obs,
               np.ascontiguousarray(flux[:,i], 'float64'),
               np.ascontiguousarray(err[:,i], 'float64'),
               np.ascontiguousarray(flag[:,i], 'bool'),
               v_0[i], v_d[i], fill, fill_val, l_cov_FWHM)
################################################################################
    

################################################################################
def _params_iter(l_obs, flux, v_0, v_d, fill, fill_val):
    '''
    Argument factory for :func:`_velocitySmooth_wrapper`.
    '''
    if flux.ndim == 1:
        N_spec = 1
    else:
        N_spec = flux.shape[1]
    for i in xrange(N_spec):
        yield (l_obs,
               np.ascontiguousarray(flux[:,i], 'float64'),
               v_0[i], v_d[i], fill, fill_val)
################################################################################
    
    
################################################################################
def _velocitySmoothFlag_wrapper(args):
    from gauss_smooth import gaussVelocitySmoothFlag  # @UnresolvedImport
    l_obs, flux, err, flag, v_0, v_d, fill, fill_val, l_cov_FWHM = args
    return gaussVelocitySmoothFlag(l_obs, flux, err, flag,
                                   v_0, v_d, n_sig=4, n_u=21,
                                   fill=fill, fill_val=fill_val,
                                   flag_threshold=0.8, l_cov_FWHM=l_cov_FWHM)
################################################################################

################################################################################
def _velocitySmooth_wrapper(args):
    from gauss_smooth import gaussVelocitySmooth  # @UnresolvedImport
    l_obs, flux, v_0, v_d, fill, fill_val = args
    return gaussVelocitySmooth(l_obs, flux, v_0, v_d, n_sig=4, n_u=21, fill=fill, fill_val=fill_val)
################################################################################

