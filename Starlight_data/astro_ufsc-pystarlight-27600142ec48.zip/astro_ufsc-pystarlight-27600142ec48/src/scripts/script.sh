#!/bin/bash
date
T="$(date +%s)"
python sdss2starlightinput.py
T="$(($(date +%s)-T))"
echo "Time in seconds: ${T}"
date
exit
