'''

  This routine reads a list of spectra and extracts 
  the FITS files, generating CXT files and ready to "STARLIGHTear".
   
  Created on Aug 23, 2012

                                       authors: William, Marcus
'''
######################################################################
import os
import atpy
import numpy as np
import cosmocalc
import pystarlight
import pyfits
from astropysics import obstools
from astropysics.coords import ICRSCoordinates,GalacticCoordinates
import sys

''' Files and Paths '''

dust_dir = '%s/%s' % (os.path.dirname(pystarlight.__file__), '../../data/dust_maps/')
dustmapfile = '%s/SFD_dust_1024_%s.fits' % (dust_dir, '%s')
fits_dir = './' #'%s/%s' % (os.path.dirname(pystarlight.__file__), '../../data/test/test_fits/')
cxt_dir = './' #%s/%s' % (os.path.dirname(pystarlight.__file__), '../../data/test/test_cxt/')

''' List of galaxies '''

list_gal= sys.argv[1]

''' Definitions '''

def readSDSSfile(fname):
    ''' Reads SDSS DR9 .fits file '''
    return atpy.Table(fname)

def dust_correct(l, b, dustmapfile):
    ebv = obstools.get_SFD_dust(l,b,dustmap=dustmapfile,interpolate=True)
    return ebv

from pystarlight.util.tools_read_fits_boss import make_aid
from pystarlight.util.read_fits_boss import read_fits_boss

''' Input parameters '''

R_V=3.1       # Extinction parameter
redlaw='CCM'  # Extinction Law
li=1000.      # Initial lambda
lf=10500.     # Final lambda
dl=1.         # Delta lambda (Resampling)

####################################################################

table=atpy.Table(list_gal, type='ascii')
ngal=len(table.data) # Number of galaxies
# The table must have the parameters as below!
plate=[]     # 1 col
mjd=[]       # 2 col
fiber=[]     # 3 col
ra=[]        # 4 col
dec=[]       # 5 col
redshift=[]  # 6 col
#
#ngal=1 # testing
print 'ngal=',ngal
for i in range(0, ngal):
    plate.append(int(table.data[i][0]))
    mjd.append(int(table.data[i][1]))
    fiber.append(int(table.data[i][2]))
    ra.append(float(table.data[i][3]))
    dec.append(float(table.data[i][4]))
    redshift.append(float(table.data[i][5]))

#   Making AID

aid=make_aid(plate,mjd,fiber,DR='BOSS')
aid = ['0'+a for a in aid]

#   Extracting the FITS files

for i in range(0,ngal):
    infile=fits_dir+'spec-'+aid[i]+'.fits'
    outfile=aid[i].strip()+'.cxt'
    print outfile.strip(),i

#   Galactic coord -> Equatorial coord

    galcoord = ICRSCoordinates(ra[i],dec[i]).convert(GalacticCoordinates)

#   Dust: E(B-V) 

    ebv=dust_correct(galcoord.l.degrees,galcoord.b.degrees,dustmapfile=dustmapfile)

#   Extracting the FITS file (+ Cosmology, Extinction, Resampling,...)

    l,f,error,flag=read_fits_boss(infile,outfile,ebv,R_V,redshift[i],redlaw,li,lf,dl)

#   Output

    f_out = open(cxt_dir.strip()+outfile.strip(), 'w')
    for j in range(len(l)):
     string=' % 10.5F % 10.5F % 10.5F % 2d \n' % (l[j],f[j],error[j],int(flag[j]))
     f_out.writelines(string)
    f_out.close()
if __name__ == '__main__':
    pass
