'''
Created on Mar 5, 2013

@author: william
'''

import gc
import atpy
import pystarlight.io

tables_dir = '/net/Starlight_SDSS/DR7/tables/'
out_dir = '/home/william/'
prefix = 'sample.FDR7.926246.f'
suffix = 'BS'
ascii_compression = 'bz2'

######### SYN tables ########
for i_table in [1,2,3,4]:
    print('Converting SYN0%s table...' % i_table)
    tb = atpy.Table('%s/%s.Starlight.SYN0%s.tab.%s.%s' % (tables_dir, prefix, i_table, suffix, ascii_compression), type='starlight_syn0%s' % i_table )
    tb.write('%s/%s.Starlight.SYN0%s.tab.%s.hdf5' % (out_dir, prefix, i_table, suffix), compression='gzip')
    del tb
    gc.collect()
 
######### PARAM tables ########
print('Converting PARAMETERS table...')
tb = atpy.Table('%s/%s.parameters.dat.%s' % (tables_dir, prefix, ascii_compression), type='starlight_param')
tb.write('%s/%s.parameters.dat.%s.hdf5' % (out_dir, prefix, suffix), compression='gzip')
del tb
gc.collect()
 
######## EL tables ########
print('Converting EMISSION LINES table...')
tb = atpy.Table('%s/%s.lines.dat.%s.%s' % (tables_dir, prefix, suffix, ascii_compression), type='starlight_el')
tb.write('%s/%s.lines.dat.%s.hdf5' % (out_dir, prefix, suffix), compression='gzip')
del tb
gc.collect()