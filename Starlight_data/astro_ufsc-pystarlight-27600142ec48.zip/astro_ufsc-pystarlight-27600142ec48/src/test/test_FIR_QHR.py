'''
Created on 01/Jul/2012

@author: Andre Luiz de Amorim,
         William Schoenell,
         Natalia

Based on test.py

'''
import atpy
import pystarlight.io.starlighttable #io.starlighttable #@UnusedImport
import matplotlib.pyplot as plt
import numpy as np

def testStarlightReaderFIRQHR(data='../../data/test/STARLIGHT_test_output_FIR_QHR.txt', typ='starlight'):
    ts = atpy.TableSet(data, type=typ)

    print ts.keywords['FIR_arq_ETCinfo']
    print ts.keywords['FIR_LumDistInMpc']
    print ts.keywords['FIR_logLFIR_TOTInLsun']
    print ts.keywords['FIR_LFIRFrac2Model']
    print ts.keywords['FIR_logLFIR_obsInLsun']
    print ts.keywords['FIR_ErrlogLFIRInDex']
    print ts.keywords['FIR_RangelogLFIRInDex']
    print ts.keywords['FIRChi2ScaleFactor']
    print ts.keywords['FIR_logLFIR_lowInLsun']
    print ts.keywords['FIR_logLFIR_uppInLsun']
    print ts.keywords['FIRbeta_D']
    print ts.keywords['FIRbeta_I']
    print ts.keywords['log_LFIR/LOpt_rough']

    print ts.keywords['FIRModlogLFIRInLsun']
    print ts.keywords['FIRModObsRatio']
    print ts.keywords['FIRModlogLBOLInLsun']
    print ts.keywords['FIR_BOL_Ratio']
    print ts.keywords['chi2_FIR']
    print ts.keywords['chi2_Opt']
    print ts.keywords['chi2_FIR/TOT_Perc']
    print ts.keywords['chi2_Opt/TOT_Perc']

    print
    ts.FIR.describe()
    #print ts.FIR['x_FIR']
    #print ts.FIR['R_LCE']

    print
    print ts.keywords['QHRbeta_I']
    print ts.keywords['QHR_arq_ETCinfo']
    print ts.keywords['QHR_LumDistInMpc']
    print ts.keywords['QHR_GlobalChi2ScaleFactor']
    print ts.keywords['NQHR_Ys']

    print
    print ts.QHR_Obs.describe()
    #print ts.QHR_Obs['lambda']
    #print ts.QHR_Obs['logY_upp']

    print
    print ts.keywords['IsELROn']
    print ts.keywords['ELR_lambda_A']
    print ts.keywords['ELR_lambda_B']
    print ts.keywords['ELR_ind_A']
    print ts.keywords['ELR_ind_B']
    print ts.keywords['ELR_logRint']
    print ts.keywords['ELR_AV_neb']
    print ts.keywords['ELR_errAV_neb']

    print
    print ts.keywords['ELR_Err_logR']
    print ts.keywords['ELR_RangelogR']
    print ts.keywords['ELR_logR_low']
    print ts.keywords['ELR_logR_upp']
    print ts.keywords['ELR_Chi2ScaleFactor']

    print
    print ts.keywords['ELR_logRobs']
    print ts.keywords['ELR_ModlogR']
    print ts.keywords['ELR_chi2_ELR']
    print ts.keywords['ELR_chi2_ELR/chi2_QHR']
    print ts.keywords['ELR_chi2_ELR/chi2_TOT']

    print
    print ts.keywords['log_QH0_PhotPerSec']
    print ts.keywords['log_QHeff_PhotPerSec']
    print ts.keywords['chi2_QHR/TOT_Perc']
    print ts.keywords['chi2_Opt/TOT_Perc']
    print ts.keywords['chi2_QHR']
    print ts.keywords['chi2_Opt']
    print ts.keywords['chi2_TOT']

    print
    print ts.QHR_Mod.describe()
    print ts.QHR_Mod['lambda']
    print ts.QHR_Mod['ModlogY']

    print
    print ts.QHR.describe()
    #print ts.QHR['qH__40']
    #print ts.QHR['QH2Lnorm__40']
    #print ts.QHR['Y_Perc_Line1']

    ageBase = np.unique(ts.population.popage_base)
    ZBase = np.unique(ts.population.popZ_base)

    plt.subplot(211)
    x_FIR = ts.FIR.x_FIR.reshape([len(ZBase), len(ageBase)])
    plt.imshow(x_FIR)
    plt.xlabel('Age base')
    plt.ylabel('Metallicity base')
    plt.title('x_FIR [%]')

    plt.subplot(212)
    QH0_Perc = ts.QHR.QH0_Perc.reshape([len(ZBase), len(ageBase)])
    plt.imshow(QH0_Perc)
    plt.xlabel('Age base')
    plt.ylabel('Metallicity base')
    plt.title('QH0 [%]')

    
if __name__ == '__main__':
    print 'TEST 1'
    print 'Version 5: FIR/QHR...'
    testStarlightReaderFIRQHR()

