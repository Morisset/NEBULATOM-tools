'''
Created on Jul 2, 2012

@author: william
'''

import atpy
import numpy as np
import matplotlib.pyplot as plt

import pystarlight.io.EmissionLinesTable #@UnusedImport


file_test = '../../data/test/STARLIGHT_test_input.7xt.bz2'

if __name__ == '__main__':
    
    ti = atpy.TableSet(file_test, type='starlight_input')
    
    plt.clf()
    plt.plot(ti.starlight_input['lambda'], ti.starlight_input['flux'], color='black') #All
    aux_ = np.ma.masked_where(ti.starlight_input['flag'] < 2, ti.starlight_input['flux'])
    plt.plot(ti.starlight_input['lambda'], aux_, color='red') #If flag > 2
    plt.plot(ti.starlight_input['lambda'], ti.starlight_input['error'], color='blue')

    plt.title(ti.keywords['filename'])
    plt.xlim(np.min(ti.starlight_input['lambda'])-20,np.max(ti.starlight_input['lambda'])+20)