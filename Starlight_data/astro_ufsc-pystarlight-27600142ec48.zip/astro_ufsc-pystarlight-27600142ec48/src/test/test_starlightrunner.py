'''
Created on Aug 2, 2013

@author: andre
'''
from pystarlight.util import starlight_runner as sr
from pystarlight.util.gridfile import GridFile
from pystarlight.mock import mock_starlight
import os

starlight_dir = '../../data/test/starlightrunner'
grid_dir = os.path.join(starlight_dir, 'grids')

# Replace by the starlight executable path,
# or remove if you have starlight in your path.
sr.starlight_exec_path = mock_starlight.__file__

# If starlight_checker is not in the path, set it here.
# sr.checker_exec_path = '/Users/andre/astro/starlight/starlight_checker'

# This is the queue manager.
runner = sr.StarlightRunner(n_workers=1, timeout=20 * 60.0) # 2 processes, 20 minutes limit

# Create grids an add to the runner (this will block if the queue gets full).
for gridfile in os.listdir(grid_dir):
    grid = GridFile.fromFile(starlight_dir, os.path.join(grid_dir, gridfile))
    runner.addGrid(grid)

print 'Waiting jobs completion.'
runner.wait()

# See which runs failed.
failed = runner.getFailedGrids()
if len(failed) > 0:
    print 'Failed to starlight:'
    for grid in failed:
        print '\n'.join(r.outFile for r in grid.failed)
