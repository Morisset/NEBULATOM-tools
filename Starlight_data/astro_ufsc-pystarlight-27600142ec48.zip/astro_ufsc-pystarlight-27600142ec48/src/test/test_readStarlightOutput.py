'''
Created on Mar 7, 2012

@author: Andre Luiz de Amorim,
         William Schoenell

'''
import atpy
import pystarlight.io.starlighttable #io.starlighttable #@UnusedImport
import matplotlib.pyplot as plt
import numpy as np

def testStarlightReader(data='../../data/test/STARLIGHT_test_output.txt', typ='starlight'):
    ts = atpy.TableSet(data, type=typ)
    ts.tables
    ts.population.describe()
    ts.spectra.describe()
    
    if typ == 'starlight':
        ts.chains_par.describe()
        ts.chains_LAx.describe()
        ts.chains_mu_cor.describe()
    print 'Keywords:'
    for k,v in ts.keywords.items():
        print '%-016s: %s' % (k,v)
    
    ageBase = np.unique(ts.population.popage_base)
    ZBase = np.unique(ts.population.popZ_base)
    
    plt.subplot(211)
    popmu_cor = ts.population.popmu_cor.reshape([len(ZBase), len(ageBase)])
    plt.imshow(popmu_cor)
    plt.xlabel('Age base')
    plt.ylabel('Metallicity base')
    plt.title('popmu_cor')
    
    plt.subplot(212)
    residual = ts.spectra.f_obs - ts.spectra.f_syn
    plt.plot(ts.spectra.l_obs, residual)
    plt.xlabel('Wavelength [\\AA]')
    plt.ylabel('Residual spectrum [flux]')
    plt.show()
    
def testBaseReader(basefile='/Users/william/work/templates/Base.BC03.S', basedir='/Users/william/mestrado/BasesDir/', typ='starlightv4_base'):
    bt = atpy.TableSet(basefile, basedir, read_basedir=True, type=typ)
    return bt

if __name__ == '__main__':
    print 'TEST 1'
    print 'Version 5...'
    testStarlightReader()
    print 'Press enter to continue'
    raw_input()
    print 'Version 4...'
    testStarlightReader(data='../../data/test/STARLIGHT_test_output_v04.txt', typ='starlightv4')
    print 'Press enter to continue'
    raw_input()
    print 'Basefile - v04'
    bt = testBaseReader()