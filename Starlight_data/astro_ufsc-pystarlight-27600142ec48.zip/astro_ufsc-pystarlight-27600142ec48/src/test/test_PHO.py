'''
Created on 06/Feb/2013

@author: Andre Luiz de Amorim,
         William Schoenell,
         Natalia

Based on test.py

'''
import atpy
import pystarlight.io.starlighttable #io.starlighttable #@UnusedImport
import matplotlib.pyplot as plt
import numpy as np

def testStarlightReaderPHO(data='../../data/test/STARLIGHT_test_output_PHO.txt', typ='starlight'):
    ts = atpy.TableSet(data, type=typ)

    print
    print ts.keywords['PHO_arq_ETCinfo']
    print ts.keywords['PHO_LumDistInMpc']
    print ts.keywords['PHO_Redshift']
    print ts.keywords['PHO_GlobalChi2ScaleFactor']
    print ts.keywords['NPHO_Ys']

    print
    print ts.PHO_Obs.describe()
    print ts.PHO_Obs['name']
    print ts.PHO_Obs['logY_TOT']

    print ts.keywords['chi2_PHO/TOT_Perc']
    print ts.keywords['chi2_Opt/TOT_Perc']
    print ts.keywords['chi2_PHO']
    print ts.keywords['chi2_Opt']
    print ts.keywords['chi2_TOT']

    print
    print ts.PHO_Mod.describe()
    print ts.PHO_Mod['MeanLamb']
    print ts.PHO_Mod['ModlogY']

    print
    print ts.PHO.describe()
    print ts.PHO['Y_Perc']

    ageBase = np.unique(ts.population.popage_base)
    ZBase = np.unique(ts.population.popZ_base)
    
    plt.ioff()
    plt.subplot(111)
    nPHO_Ys = ts.keywords['NPHO_Ys']
    for y in range(nPHO_Ys):
        plt.subplot(nPHO_Ys, 1, y)
        Y_Perc = ts.PHO.Y_Perc[:,y].reshape([len(ZBase), len(ageBase)])
        plt.imshow(Y_Perc, interpolation='nearest')
        plt.colorbar()
        plt.xlabel('Age')
        plt.ylabel('Met.')
        plt.title('Y [%%] %s' % ts.PHO_Obs.name[y])

    plt.show()
    
if __name__ == '__main__':
    print 'TEST 1'
    print 'Version 5: PHO...'
    testStarlightReaderPHO()

