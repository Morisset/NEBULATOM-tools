'''
Created on Jun 12, 2013

@author: andre
'''


from pystarlight.util.StarlightUtils import gaussVelocitySmooth
import atpy
import pystarlight.io.starlighttable #io.starlighttable #@UnusedImport
import matplotlib.pyplot as plt

data='../../data/test/STARLIGHT_test_output.txt'

ts = atpy.TableSet(data, type='starlight')
fo = ts.spectra.f_syn
lo = ts.spectra.l_obs

vo = 500.0
sig = 500.0

fs = gaussVelocitySmooth(lo, fo, vo, sig)
plt.ioff()
plt.figure()
plt.subplot(111)
plt.plot(lo, fo, 'r-')
plt.plot(lo, fs, 'b-')
plt.show()