'''
Created on May 16, 2012

@author: william

'''
import atpy
import pystarlight.io.starlighttable #@UnusedImport
from pystarlight.plots.plotstarlightfits import plot_fits_and_SFH

def testStarlightReader(data='../../data/test/STARLIGHT_test_output.txt', typ='starlight'):
    ts = atpy.TableSet(data, type=typ)

    ts.population.describe()
    ts.spectra.describe()
    print 'Keywords:'
    for k,v in ts.keywords.items():
        print '%-016s: %s' % (k,v)
    
    lix = plot_fits_and_SFH(ts)
#    lix.plot_fig_starlight()
    lix.plot_fig_starlight(smooth_plot=30)
    lix.draw_legends()
    lix.axleft_upp.set_ylim(-.3,3) #For spec limits
    lix.axleft_upp.grid(True) #For grid on spec
    lix.axleft_low.grid(True) #For grid on resiuals
    return lix

if __name__ == '__main__':
    print 'TEST 1'
    print 'Version 5...'
    lix = testStarlightReader()
    print 'Press enter to continue'
    raw_input()
    print 'Version 4...'
    lix = testStarlightReader(data='../../data/test/STARLIGHT_test_output_v04.txt', typ='starlightv4')
    lix.fig.savefig('test.eps')
    raw_input()
    