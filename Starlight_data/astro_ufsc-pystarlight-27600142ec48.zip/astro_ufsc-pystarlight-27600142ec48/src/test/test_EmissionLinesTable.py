'''
Created on Mar 7, 2012

@author: Andre Luiz de Amorim

'''
import atpy
import pystarlight.io.EmissionLinesTable #@UnusedImport
import matplotlib.pyplot as plt
import numpy as np

def testEmissionLineReader_newfits(data='../../data/test/Elines_test_output.txt'):
    te = atpy.Table(data, type='newfits_el')

    te.describe()
    print 'Keywords:'
    kw = zip(te.keywords.keys, te.keywords.values)
    #for k in te.keywords.keys:
        #print '%-016s: %s' % (k,te.keywords[k])
    for k,v in kw:
        print '%-016s: %s' % (k,v)

    El_lambda = te['lambda']
    El_F      = te['El_F']
    El_SN     = te['El_SN']

    flag_6563 = abs(El_lambda - 6563) < 2
    El_F_6563 = El_F[flag_6563]
    flag_4861 = abs(El_lambda - 4861) < 2
    El_F_4861 = El_F[flag_4861]
    flag_6584 = abs(El_lambda - 6584) < 2
    El_F_6584 = El_F[flag_6584]
    flag_5007 = abs(El_lambda - 5007) < 2
    El_F_5007 = El_F[flag_5007]

    HaHb = np.log10(abs(El_F_6563 / El_F_4861))
    N2Ha = np.log10(abs(El_F_6584 / El_F_6563))
    O3Hb = np.log10(abs(El_F_5007 / El_F_4861))

    # CAL extinction indices
    lHb = 0.4861325
    lHa = 0.656280
    qHb_CAL = (2.659 / 4.05) * ( -2.156 + 1.509 / lHb - 0.198 / lHb**2 + 0.011 / lHb**3 ) + 1
    qHa_CAL = (2.659 / 4.05) * ( -1.857 + 1.040 / lHa ) + 1
    AV_neb = 2.5 / (qHb_CAL - qHa_CAL) * (HaHb - np.log10(2.863))

    print 'AV_neb = ', AV_neb
    

    x = np.linspace(-2.0, -0.21, 1000)
    S06_line = 0.96 + 0.29 / (x + 0.20)

    #set __x = -3,2,0.01
    #set y_Kewl = (__x <  0.47) ? 1.19 + 0.61 / (__x - 0.47) : -999
    #set y_Kauf = (__x <  0.05) ? 1.30 + 0.61 / (__x - 0.05) : -999
    #set y_Graz = (__x < -0.20) ? 0.96 + 0.29 / (__x + 0.20) : -999
        
    #popmu_cor = ts.population.popmu_cor.reshape([len(ZBase), len(ageBase)])
    plt.figure(1)
    plt.clf()
    plt.axis([-2, 2, -2, 2])
    plt.plot(x, S06_line)
    plt.plot(N2Ha, O3Hb, 'o')

def testEmissionLineReader_starlight(data='../../data/test/Elines_Cid_example.txt'):
    te = atpy.Table(data, type='starlight_el', el_skip = (6731, 4471))

    te.describe()
    print 'Keywords:'
    kw = zip(te.keywords.keys, te.keywords.values)
    #for k in te.keywords.keys:
        #print '%-016s: %s' % (k,te.keywords[k])
    for k,v in kw:
        print '%-016s: %s' % (k,v)
        
    HaHb = np.log10(abs(te['F_6563'] / te['F_4861']))
    N2Ha = np.log10(abs(te['F_6584'] / te['F_6563']))
    O3Hb = np.log10(abs(te['F_5007'] / te['F_4861']))

    # CAL extinction indices
    lHb = 0.4861325
    lHa = 0.656280
    qHb_CAL = (2.659 / 4.05) * ( -2.156 + 1.509 / lHb - 0.198 / lHb**2 + 0.011 / lHb**3 ) + 1
    qHa_CAL = (2.659 / 4.05) * ( -1.857 + 1.040 / lHa ) + 1
    AV_neb = 2.5 / (qHb_CAL - qHa_CAL) * (HaHb - np.log10(2.863))

    print 'AV_neb = ', AV_neb
    
    x = np.linspace(-2.0, -0.21, 1000)
    S06_line = 0.96 + 0.29 / (x + 0.20)
    
    plt.figure(2)
    plt.clf()
    plt.axis([-2, 2, -2, 2])
    plt.plot(x, S06_line)
    plt.plot(N2Ha, O3Hb, 'o')
    
    
if __name__ == '__main__':
    print 'test 1: newfits'
    testEmissionLineReader_newfits()

    print 'test 2: starlight table'
    testEmissionLineReader_starlight()