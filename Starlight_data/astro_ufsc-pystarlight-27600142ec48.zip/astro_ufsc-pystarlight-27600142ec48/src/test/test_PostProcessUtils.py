'''
Created on Jun 18, 2012

@author: william
'''

import numpy as np
import matplotlib.pyplot as plt
import atpy

import pystarlight.io #@UnusedImport
from pystarlight.util.PostProcessUtils import popvec, massvec
from pystarlight.util.base import StarlightBase

file_test = '/Users/andre/astro/qalifa/SpecMorph/data/starlight/output_bulge/K0846_0000_eBR_px1_q043_d14a512_ps03_k1_mE_CCM_Bgsd6e.f_obs.bulge.out.bz2'
basedir = '/Users/andre/astro/qalifa/SpecMorph/data/starlight/BasesDir/'
starlightdir = '/Users/andre/astro/qalifa/SpecMorph/data/starlight/'
dir_bc03_models = '/Users/william/mestrado/bc03/models/Padova1994/chabrier/'
interactive = False

ts = atpy.TableSet(file_test, type='starlight')

print 'File:', file_test
for key in ts.keywords.keys():
    print key+':', ts.keywords[key]

pop = popvec(ts)
print 'at_flux', pop.at_flux
print 'at_mass', pop.at_mass
print 'am_flux', pop.am_flux
print 'am_mass', pop.am_mass

basefile = ts.keywords['arq_base']
base = StarlightBase(starlightdir+basefile, basedir)
mass = massvec(ts, base)
print 'M2L_{SDSSu}:',mass.M2Lcor_filter('../../data/test/filters_sdss/u.dat')
print 'M2L_{SDSSg}:',mass.M2Lcor_filter('../../data/test/filters_sdss/g.dat')
print 'M2L_{SDSSr}:',mass.M2Lcor_filter('../../data/test/filters_sdss/r.dat')
print 'M2L_{SDSSi}:',mass.M2Lcor_filter('../../data/test/filters_sdss/i.dat')
print 'M2L_{SDSSz}:',mass.M2Lcor_filter('../../data/test/filters_sdss/z.dat')

#Dirty trick to test each one of the components of the base if the M2L ratios are the same as BC03.
m2l_bc03 = []
m2l_pystarlight = []
m2l_diff = []
m2l_adev = []
ts.keywords['A_V'] = 0.0
print '#f_bc03\tM2L_v (pystarlight)\t M2L_v (BC03)'
metal_id = 'mm'
#popmu_cor = base._reshape(ts.population.popmu_cor)
for t,Z in zip(range(base.nAges), range(base.nMet)):
    if not base.baseMask[t,Z]: continue
    print 'sspfile', base.sspfile[t,Z]
    if(base.sspfile[t,Z][10:13] != metal_id):
        metal_id = base.sspfile[t,Z][10:13]
        f_bc03 = np.loadtxt(dir_bc03_models+'/bc2003_hr_'+metal_id+'_chab_ssp.4color').T
    popmu_cor = np.zeros((base.nAges, base.nMet))
    popmu_cor[t,Z] = 1.0
    ts.population.popmu_cor[:] = popmu_cor[base.baseMask]
    mass = massvec(ts, base)
    m2l_pystarlight.append(mass.M2Lcor_filter('../../data/test/filters_sdss/buser_bc03_v.res'))
    # FIXME: untested beyond this point.
    i_bc03 = np.int(base.sspfile[t,Z][23:26])
    m2l_bc03.append(f_bc03[5][i_bc03])
    m2l_diff.append( (m2l_pystarlight[-1] - m2l_bc03[-1]) )
    m2l_adev.append( np.abs(m2l_pystarlight[-1] - m2l_bc03[-1]) / m2l_bc03[-1]) 
    print '%s\t%3.4f\t%3.4f' % (base.sspfile[t,Z], m2l_pystarlight[-1], m2l_bc03[-1])
    if(interactive):
        plt.figure(1)
        plt.clf()
        plt.plot(range(len(m2l_pystarlight)), m2l_pystarlight)
        plt.plot(range(len(m2l_pystarlight)), m2l_bc03)
        plt.figure(2)
        plt.clf()
        plt.plot(range(len(m2l_pystarlight)), m2l_diff)
        plt.xlim(0,150)
        plt.ylim(-.2,.3)
        plt.figure(3)
        plt.clf()
        b_file = np.loadtxt(basedir+base.sspfile[t,Z]).T
        flag = np.bitwise_and(b_file[0] > 3000, b_file[0] < 9000)
        plt.plot(b_file[0][flag], b_file[1][flag])
        raw_input()
    
     
    
