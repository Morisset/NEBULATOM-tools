'''
Created on 04/04/2013

@author: lacerda
'''

import atpy
import numpy as np
import matplotlib.pyplot as plt

import pystarlight.io #@UnusedImport

file_test = '../../data/test/STARLIGHT_mask.txt'

if __name__ == '__main__':

    mask = atpy.Table(maskfile = file_test, type = 'starlight_mask')

    for i in range(0, len(mask)):
        print mask[i]
