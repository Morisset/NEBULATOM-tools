'''
Created on Sep 24, 2012

@author: Andre Luiz de Amorim

WARNING: this script is deprecated. It is kept here for reference only.

This is an example of a reading operation in a STARLIGHT base
stored in a HDF5 file. Please read the comments for more details.
'''

import h5py
import numpy as np
import matplotlib.pyplot as plt
import sys

# HDF5 file containing the bases.
baseAll = sys.argv[1]

# The base string is one of the root groups of the HDF5 file.
base = sys.argv[2]

print 'Reading base %s...' % base
f = h5py.File(baseAll, 'r')
try:
    # The datasets are stored in "folders" (called groups
    # in the HDF5 jargon) with the same name as the base.
    # This is how we get this group, to ease the gets for
    # the datasets below.
    g = f[base]
except:
    print 'Base %s not found.' % base
    sys.exit()
    
# Read all values of the wavelength dataset to select the
# desired window. This is a small dataset, so we read it whole
# using the .value property.
wl = g['wl'].value
l1 = np.where(wl == 3400.0)[0][0]
l2 = np.where(wl == 8750.0)[0][0]

# Now read the spectra __only__ for the slice we want:
# One every 20 ages, only one metallicity given by the
# index (from 0 to 5) and l_ini to l_fin wavelength.
# Also, read the proper slice of age_base and fix the
# wl array to reflect the values read for f_ssp. 
#
# Obs: When reading a slice of a dataset, one does not
# need to use the .value property to get the numpy array. 
Z = int(sys.argv[3])
f_ssp = g['f_ssp'][::20, Z, l1:l2]
wl = wl[l1:l2]
age_base = g['age_base'][::20]
Z_value = g['Z_base'][Z]

# Convolution window for the moving average.
window = 500
kernel = np.repeat(1.0, window) / window

# FIXME: Is there a better way to do this computation?
nAges = len(age_base)
nLambda = len(wl)
f_ssp_filtered = np.empty((nAges, nLambda))
for i in range(nAges):
    f_ssp_filtered[i] = np.convolve(f_ssp[i], kernel, 'same')

# Compute the flattened spectra while cropping the
# convolution artifacts (window/2 in each side).
# Note that we recompute l1 and l2. The previous values
# are not suitable anymore because we replaced wl by
l1 = window/2
l2 = -window/2
l_ssp = wl[l1:l2]
f_ssp_flat = (f_ssp[:, l1:l2] / f_ssp_filtered[:, l1:l2]).reshape(len(age_base), -1)

# Now plot these bastards!
plt.ioff()
plt.figure()
plt.title('Z = %f' % Z_value)
for i in range(nAges / 2):
    plt.plot(l_ssp, f_ssp_flat[i] + i)
    plt.text(3100, i + 1, '%.2f' % np.log10(age_base[i]))
plt.ylabel('Relative flux')
plt.xlabel('Wavelength [A]')
plt.show()
#plt.savefig('z%d_a_conv.pdf' % z)

plt.figure()
plt.title('Z = %f' % Z_value)
for i in range(nAges / 2 + 1, nAges):
    plt.plot(l_ssp, f_ssp_flat[i] + (i - nAges / 2 + 1))
    plt.text(3100, (i - nAges / 2 + 1) + 1, '%.2f' % np.log10(age_base[i]))
plt.ylabel('Relative flux')
plt.xlabel('Wavelength [A]')
plt.show()
#plt.savefig('z%d_b_conv.pdf' % z)
