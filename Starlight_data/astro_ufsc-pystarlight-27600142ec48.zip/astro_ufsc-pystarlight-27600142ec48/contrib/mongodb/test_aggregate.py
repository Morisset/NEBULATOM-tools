'''
Created on Mar 2, 2013

@author: andre

Sample query to test the Aggregation Framework.

This is equivalent to the following SQL:

select el.id_line, count(el.id_line) as n, sum(sr.Mcor_gal) / count(el.id_line) as avg_Mcor
from el_fit el left join synthesis_results sr on el.synid=sr.synid
where el.flux > 0
group by el.id_line

'''

import sys
import time
import pymongo

try:
    cl = pymongo.MongoClient(sys.argv[1])
    synColl = cl.starlightDR7.synthesis
except:
    print 'Could not connect to mongodb.' 
    sys.exit()
    
t1 = time.time()

res = synColl.aggregate([{'$project': {'synthesis': {'Mcor_gal': 1}, 'elines': {'_id': 1, 'flux': 1}}},
                         {'$unwind': '$elines'},
                         {'$match': {'elines.flux': {'$gt': 0.0}}},
                         {'$group': {'_id': '$elines._id', 'n': {'$sum': 1}, 'avg_Mcor': {'$avg': '$synthesis.Mcor_gal'}}}]) ; t2 = time.time()

print res

cl.close()

dt = time.time() - t1
print 'Total time: %f seconds' % dt
