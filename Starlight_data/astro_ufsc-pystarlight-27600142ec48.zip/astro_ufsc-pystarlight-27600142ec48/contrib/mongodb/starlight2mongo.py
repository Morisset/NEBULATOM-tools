'''
Created on Mar 2, 2013

@author: andre

Convert the entire STARLIGHT catalog to MongoDB.

'''

import argparse
import sys
import time
import pymongo
import struct
from os import path


################################################################################
def readRec(f, fields, types):
    if __debug__ and len(fields) != len(types):
        raise ValueError('Fields and types must have the same number of items.')
    l = f.readline()
    while (l.startswith('#')):
        l = f.readline()
    if l == '':
        return None

    rawData = l.split()
    if __debug__ and len(rawData) != len(types):
        raise ValueError('Data does not have the specified number of items.')
        
    data = [conv(x) for conv, x in zip(types, rawData)]
    return dict(zip(fields, data))
################################################################################


################################################################################
def readFixedRec(f, fields, fieldStruct, types):
    if __debug__ and len(fields) != len(types):
        raise ValueError('Fields and types must have the same number of items.')
    l = f.readline()
    while (l.startswith('#')):
        l = f.readline()
    if l == '':
        return None

    rawData = fieldStruct.unpack_from(l)
    if __debug__ and len(rawData) != len(types):
        raise ValueError('Data does not have the specified number of items.')
        
    data = [conv(x.strip()) for conv, x in zip(types, rawData)]
    return dict(zip(fields, data))
################################################################################


parFields = ['aid', 'plate', 'mjd', 'fiber', 'ra', 'dec', 'z', 'eClass',
             'm_u', 'm_g', 'm_r', 'm_i', 'm_z',
             'fm_u', 'fm_g', 'fm_r', 'fm_i', 'fm_z',
             'Mu', 'Mg', 'Mr', 'Mi', 'Mz',
             'SB_50_r', 'CI_r', 'petrorad_r', 'petroR50_r', 'petroR90_r',
             'expAB_r', 'deVAB_r', 'D', 'DA', 'R50', 'R90', 'DL', 'log_L',
             'Mr_fiber', 'log_L_fiber', 'Mz_fiber', 'log_L_fiber_z',
             'petrorad_z', 'petroR50_z', 'petroR90_z', 'DA_z', 'R50_z', 'R90_z', 'flag_duplicate']
parTypes = [str, int, int, int, float, float, float, float,
           float, float, float, float, float,
           float, float, float, float, float,
           float, float, float, float, float,
           float, float, float, float, float,
           float, float, float, float, float, float, float, float,
           float, float, float, float,
           float, float, float, float, float, float, int]

objIdFields = ['plate', 'mjd', 'fiber', 'objId', 'specObjId']
objIdTypes = [int, int, int, int, int]

syn01Fields = ['syn_file', 'x_PL', 'x_Y', 'x_I', 'x_O', 'mu_Y', 'mu_I', 'mu_O',
               'A_V', 'v0', 'vd', 'chi2', 'adev', 'SN_w', 'SN_n', 'OSN_w', 'OSN_n', 'Nn0', 'NOl_eff', 'Nl_eff']
syn01Types = [str, float, float, float, float, float, float, float,
             float, float, float, float, float, float, float, float, float, int, int, int]

syn02Fields = ['syn_file', 'at_flux', 'at_mass', 'aZ_flux', 'aZ_mass', 'am_flux', 'am_mass',
               'st_flux', 'st_mass', 'sZ_flux', 'sZ_mass', 'sm_flux', 'sm_mass',
               'i_boc', 'boc_age', 'boc_Z', 'boc_chi2', 'boc_adev', 'boc_AV']
syn02Types = [str, float, float, float, float, float, float,
             float, float, float, float, float, float,
             float, float, float, float, float, float]

syn03Fields = ['syn_file', 'M2L_u', 'M2L_g', 'M2L_r', 'M2L_i', 'M2L_z', 'M2L_B', 'M2L_V', 'M2L_BOL']
syn03Types = [str, float, float, float, float, float, float, float, float]

syn04Fields = ['syn_file', 'Mcor_fib', 'Mini_fib', 'Mret_fib', 'Mcor_gal', 'Mini_gal', 'Mret_gal',
               'Den_Mcor', 'Den_Mini', 'Mpho_gal', 'fobs_norm', 'Flux_tot', 'log_Lnorm', 'log_Ltot',
               'z', 'DL_Mpc', 'FibCor', 'HLR_kpc', 'Mz_gal', 'tz_lookback']
syn04Types = [str, float, float, float, float, float, float,
             float, float, float, float, float, float, float,
             float, float, float, float, float, float]

cfgElFields = ['_id', 'name', 'wl_central', 'wl_low_blue_con', 'wl_upp_blue_con', 'wl_low_red_con', 'wl_upp_red_con']
cfgElTypes = [int, str, float, float, float, float, float]

elFieldsRaw = ['syn_file',
            'flux_3727', 'sigflux_3727', 'EW_3727', 'sigEW_3727', 'vd_3727', 'sigvd_3727',
            'v0_3727', 'sigv0_3727', 'SN_3727', 'fc_3727', 'sigfc_3727',
            'flux_3869', 'sigflux_3869', 'EW_3869', 'sigEW_3869', 'vd_3869', 'sigvd_3869',
            'v0_3869', 'sigv0_3869', 'SN_3869', 'fc_3869', 'sigfc_3869',
            'flux_4101', 'sigflux_4101', 'EW_4101', 'sigEW_4101', 'vd_4101', 'sigvd_4101',
            'v0_4101', 'sigv0_4101', 'SN_4101', 'fc_4101', 'sigfc_4101',
            'flux_4340', 'sigflux_4340', 'EW_4340', 'sigEW_4340', 'vd_4340', 'sigvd_4340',
            'v0_4340', 'sigv0_4340', 'SN_4340', 'fc_4340', 'sigfc_4340',
            'flux_4363', 'sigflux_4363', 'EW_4363', 'sigEW_4363', 'vd_4363', 'sigvd_4363',
            'v0_4363', 'sigv0_4363', 'SN_4363', 'fc_4363', 'sigfc_4363',
            'flux_4861', 'sigflux_4861', 'EW_4861', 'sigEW_4861', 'vd_4861', 'sigvd_4861',
            'v0_4861', 'sigv0_4861', 'SN_4861', 'fc_4861', 'sigfc_4861',
            'flux_4959', 'sigflux_4959', 'EW_4959', 'sigEW_4959', 'vd_4959', 'sigvd_4959',
            'v0_4959', 'sigv0_4959', 'SN_4959', 'fc_4959', 'sigfc_4959',
            'flux_5007', 'sigflux_5007', 'EW_5007', 'sigEW_5007', 'vd_5007', 'sigvd_5007',
            'v0_5007', 'sigv0_5007', 'SN_5007', 'fc_5007', 'sigfc_5007',
            'flux_6300', 'sigflux_6300', 'EW_6300', 'sigEW_6300', 'vd_6300', 'sigvd_6300',
            'v0_6300', 'sigv0_6300', 'SN_6300', 'fc_6300', 'sigfc_6300',
            'flux_6548', 'sigflux_6548', 'EW_6548', 'sigEW_6548', 'vd_6548', 'sigvd_6548',
            'v0_6548', 'sigv0_6548', 'SN_6548', 'fc_6548', 'sigfc_6548',
            'flux_6563', 'sigflux_6563', 'EW_6563', 'sigEW_6563', 'vd_6563', 'sigvd_6563',
            'v0_6563', 'sigv0_6563', 'SN_6563', 'fc_6563', 'sigfc_6563',
            'flux_6584', 'sigflux_6584', 'EW_6584', 'sigEW_6584', 'vd_6584', 'sigvd_6584',
            'v0_6584', 'sigv0_6584', 'SN_6584', 'fc_6584', 'sigfc_6584',
            'flux_6717', 'sigflux_6717', 'EW_6717', 'sigEW_6717', 'vd_6717', 'sigvd_6717',
            'v0_6717', 'sigv0_6717', 'SN_6717', 'fc_6717', 'sigfc_6717',
            'flux_6731', 'sigflux_6731', 'EW_6731', 'sigEW_6731', 'vd_6731', 'sigvd_6731',
            'v0_6731', 'sigv0_6731', 'SN_6731', 'fc_6731', 'sigfc_6731',
            'flux_4471', 'sigflux_4471', 'EW_4471', 'sigEW_4471', 'vd_4471', 'sigvd_4471',
            'v0_4471', 'sigv0_4471', 'SN_4471', 'fc_4471', 'sigfc_4471']
elFieldSizes = [14,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10]
elFieldStructFmt = ''.join('%ds' % s for s in elFieldSizes)
elFieldStruct = struct.Struct(elFieldStructFmt)
elTypesRaw = [str,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float,
          float, float, float, float, float, float,
          float, float, float, float, float]

elFields = ['flux', 'sigflux', 'EW', 'sigEW', 'vd', 'sigvd', 'v0', 'sigv0', 'SN', 'fc', 'sigfc']
elIndex = []
for f in elFieldsRaw:
    if f.startswith('flux'):
        elIndex.append(int(f.split('_')[1]))

parser = argparse.ArgumentParser(description='Import STARLIGHT tables.')
parser.add_argument('--syn01', dest='syn01FileName', default='sample.FDR7.926246.f.Starlight.SYN01.tab.BS',
                    help='Path to SYN01 file.')
parser.add_argument('--syn02', dest='syn02FileName', default='sample.FDR7.926246.f.Starlight.SYN02.tab.BS',
                    help='Path to SYN02 file.')
parser.add_argument('--syn03', dest='syn03FileName', default='sample.FDR7.926246.f.Starlight.SYN03.tab.BS',
                    help='Path to SYN03 file.')
parser.add_argument('--syn04', dest='syn04FileName', default='sample.FDR7.926246.f.Starlight.SYN04.tab.BS',
                    help='Path to SYN04 file.')
parser.add_argument('--param', dest='parFileName', default='sample.FDR7.926246.f.parameters.dat',
                    help='Path to parameters file.')
parser.add_argument('--el', dest='elFileName', default='sample.FDR7.926246.f.lines.dat.BS',
                    help='Path to elines file.')
parser.add_argument('--cfg-el', dest='cfgElFileName', default='sample.FDR7.926246.f.cfg-lines.dat',
                    help='Path to elines config file.')
parser.add_argument('--obj-id', dest='objIdFileName', default='sample.FDR7.926246.f.objid.dat',
                    help='Path to SDSS object ID file.')
parser.add_argument('-n', dest='maxRecords', type=int, default=926246,
                    help='Maximum number of records to process.')
parser.add_argument('--db', dest='dbName', default='starlightDR7',
                    help='Database name.')
parser.add_argument('--host', dest='host', default='localhost:27017',
                    help='Mongo host. Ex.: \'localhost\' or \'localhost:27017\'.')
args = parser.parse_args()

if __debug__:
    print 'Debug'
    
loadCfgEl = path.exists(args.cfgElFileName)
loadObjId = path.exists(args.objIdFileName)

try:
    parFile = open(args.parFileName, 'r')
    elFile = open(args.elFileName, 'r')
    syn01File = open(args.syn01FileName, 'r')
    syn02File = open(args.syn02FileName, 'r')
    syn03File = open(args.syn03FileName, 'r')
    syn04File = open(args.syn04FileName, 'r')
    if loadObjId:
        print 'loading objID from %s.' % args.objIdFileName
        objIdFile = open(args.objIdFileName, 'r')
    if loadCfgEl:
        print 'loading elines config from %s.' % args.cfgElFileName
        cfgElFile = open(args.cfgElFileName, 'r')
except:
    print 'File not found.'
    sys.exit()

try:
    cl = pymongo.MongoClient(args.host)
    synColl = cl[args.dbName].synthesis
    cfgElColl = cl[args.dbName].cfg_elines
except:
    print 'Could not connect to local mongodb.' 
    sys.exit()
    
t1 = time.time()
i = 0

if loadCfgEl:
    for i in xrange(args.maxRecords):
        rec = readRec(cfgElFile, cfgElFields, cfgElTypes)
        if rec is None: break
        cfgElColl.insert(rec)

for i in xrange(args.maxRecords):
    if i % 10000 == 0:
        dt = time.time() - t1
        dndt = i / dt
        print 'done %i so far, in %.2f seconds (dn/dt = %.2f)...' % (i, dt, dndt)

    obs_params = readRec(parFile, parFields, parTypes)
    if obs_params is None:
        break
    if loadObjId:
        objIdRec = readRec(objIdFile, objIdFields, objIdTypes)
        _id = objIdRec['specObjId']
        obs_params['objId'] = objIdRec['objId']
        obs_params['specObjId'] = objIdRec['specObjId']
    else:
        _id=obs_params['aid']
    
    synthesis = readRec(syn01File, syn01Fields, syn01Types)
    synthesis.update(readRec(syn02File, syn02Fields, syn02Types))
    synthesis.update(readRec(syn03File, syn03Fields, syn03Types))
    synthesis.update(readRec(syn04File, syn04Fields, syn04Types))

    elinesRaw = readFixedRec(elFile, elFieldsRaw, elFieldStruct, elTypesRaw)
    elines = []
    for idx in elIndex:
        # TODO: find undetected lines
        el = {}
        el['_id'] = idx
        for prefix in elFields:
            el[prefix] = elinesRaw['%s_%s' % (prefix, idx)]
        elines.append(el)

    rec = dict(_id=_id, obs_params=obs_params, synthesis=synthesis, elines=elines)
    synColl.insert(rec)
    
nRecords = i
    
parFile.close()
elFile.close()
syn01File.close()
syn02File.close()
syn03File.close()
syn04File.close()
if loadCfgEl:
    cfgElFile.close()
if loadObjId:
    objIdFile.close()
cl.close()

dt = time.time() - t1
dndt = nRecords / dt
print 'Total: %i records in %.2f seconds (dn/dt = %.2f).' % (nRecords, dt, dndt)
