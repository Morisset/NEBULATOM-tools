'''
Created on May 28, 2013

@author: andre
'''

import numpy as np
import struct

################################################################################
def convert(x, t):
    conv = {'float32': float,
            'int32': int,
            'int64': np.int64}
    if t in conv.keys():
        return conv[t](x)
    elif t.startswith('S'):
        return str(x)
    else:
        raise ValueError('Unknown type: %s' % t)
################################################################################


################################################################################
class TextFileReader(object):
    fields = []
    types = []
    
    def __init__(self, fileName, fields, types):
        if len(fields) != len(types):
            raise ValueError('Fields and types must have the same number of items.')
        self._currentLine = 0
        self.fields = fields
        self.types = types
        self._file = open(fileName, 'r')
        
    
    def close(self):
        self._file.close()
        
        
    def _readRawLine(self):
        l = self._file.readline()
        self._currentLine += 1
        while (l.startswith('#')):
            l = self._file.readline()
        if l == '':
            return None
        return l
    
    
    def readLine(self):
        rawLine = self._readRawLine()
        if rawLine is None:
            return None
        return rawLine.split()
    
        
    def readRec(self):
        
        data = self.readLine()
        if data is None:
            return None
        if len(data) != len(self.types):
            print '%d: %s' % (self._currentLine, data)
            
            raise ValueError('Data does not have the specified number of items.')
        
        try:
            rec = [convert(x, t) for t, x in zip(self.types, data)]
        except:
            print 'Could not read line:'
            print data
            raise
        return tuple(rec)
    
    
    def readDict(self):
        return dict(zip(self.fields, self.readRec()))
################################################################################


################################################################################
class FixedTextFileReader(TextFileReader):
    _fieldStruct = None
    
    def __init__(self, fileName, fields, fieldSizes, types):
        fieldStructFmt = ''.join('%ds' % s for s in fieldSizes)
        self._fieldStruct = struct.Struct(fieldStructFmt)
        TextFileReader.__init__(self, fileName, fields, types)
        
        
    def readLine(self):
        rawLine = self._readRawLine()
        if rawLine is None:
            return None
        rawData = self._fieldStruct.unpack_from(rawLine )
        return [x.strip() for x in rawData]
################################################################################


