'''
Created on Mar 2, 2013

@author: andre

Convert the entire STARLIGHT catalog to MongoDB.

'''

import argparse
import sys
import time

from numpy import dtype
from tables import openFile, Description, Col
from synthesis_file_spec import SynthesisReader
from synthesis_file_spec import synFields, synTypes, parFields, parTypes
from synthesis_file_spec import elFields, elTypes, cfgElFields, cfgElTypes
from tables.filters import Filters


################################################################################
def descr_from_dtype(fields, types):
    if len(fields) != len(types):
        raise ValueError('Fields and types must have the same number of elements.')
    coldict = {}
    for i in xrange(len(fields)):
        db = fields[i]
        t = types[i]
        t = Col.from_dtype(dtype(t), pos=i)
        coldict[db] = t
    return Description(coldict)
################################################################################


################################################################################
def createFilter(complevel=1, complib='blosc'):
    return Filters(complevel=complevel, complib=complib)
################################################################################


################################################################################
parser = argparse.ArgumentParser(description='Import STARLIGHT tables.')
parser.add_argument('--base-dir', dest='baseDir', default='.',
                    help='Path to synthesis files.')
parser.add_argument('-n', dest='maxRecords', type=int, default=926246,
                    help='Maximum number of records to process.')
parser.add_argument('--db', dest='db', default='starlight_tables.h5',
                    help='Database path.')
parser.add_argument('--root', dest='root', default='/',
                    help='Path in the database where to store the table given by --table. Defaults to "/".')
parser.add_argument('--syn-table', dest='synTableName', default='synthesis',
                    help='Synthesis table name. Recommended to be alphanumeric.')
parser.add_argument('--syn-table-title', dest='synTableTitle', default='Synthesis results',
                    help='Synthesis table title.')
parser.add_argument('--par-table', dest='parTableName', default='obs_params',
                    help='Observational parameters table name. Recommended to be alphanumeric.')
parser.add_argument('--par-table-title', dest='parTableTitle', default='Observational parameters',
                    help='Obs. parameters table title.')
parser.add_argument('--el-table', dest='elTableName', default='elines',
                    help='Emission line table name. Recommended to be alphanumeric.')
parser.add_argument('--el-table-title', dest='elTableTitle', default='Emission lines',
                    help='Emission line table title.')
parser.add_argument('--cfg-el-table', dest='cfgElTableName', default='cfg_elines',
                    help='Emission line configuration table name. Recommended to be alphanumeric.')
parser.add_argument('--cfg-el-table-title', dest='cfgElTableTitle', default='Emission lines detection parameters',
                    help='Emission line configuration table title.')
parser.add_argument('--extra-index', dest='extraIndex', action='store_true',
                    help='Create extra indices (z, S/N, etc..)')
args = parser.parse_args()
    
if __debug__:
    print 'Debug enabled!'
    
try:
    reader = SynthesisReader(args.baseDir)
except Exception as e:
    print e
    print 'Could not read synthesis tables.'
    sys.exit()

try:
    db = openFile(args.db, 'w')
except Exception as e:
    print e
    print 'Could not open %s for writing.' % args.db 
    sys.exit()


t1 = time.time()

if reader.loadCfgEline:
    cfgElTableDescr = descr_from_dtype(cfgElFields, cfgElTypes)
    tCfgEl = db.createTable(args.root, args.cfgElTableName, cfgElTableDescr,
                           title=args.cfgElTableTitle, filters=createFilter())
    for i in xrange(args.maxRecords):
        rec = reader.readCfgElineRec()
        if rec is None: break
        tCfgEl.append([rec])
    tCfgEl.flush()


indexFields = ['index']
indexTypes = ['int32']
if reader.loadObjId:
    indexFields += ['specObjId', 'objId']
    indexTypes += ['int64', 'int64']

synTableDescr = descr_from_dtype(indexFields + synFields, indexTypes + synTypes)
tSyn = db.createTable(args.root, args.synTableName, synTableDescr, expectedrows=args.maxRecords,
                     title=args.synTableTitle, filters=createFilter())

parTableDescr = descr_from_dtype(indexFields + parFields, indexTypes + parTypes)
tPar = db.createTable(args.root, args.parTableName, parTableDescr, expectedrows=args.maxRecords,
                     title=args.parTableTitle, filters=createFilter())

elTableDescr = descr_from_dtype(indexFields + elFields, indexTypes + elTypes)
tEl = db.createTable(args.root, args.elTableName, elTableDescr, expectedrows=args.maxRecords*reader.elinesPerRec(),
                    title=args.elTableTitle, filters=createFilter())

for i in xrange(args.maxRecords):
    if i % 10000 == 0:
        dt = time.time() - t1
        dndt = i / dt
        print 'done %i so far, in %.2f seconds (dn/dt = %.2f)...' % (i, dt, dndt)

    idRec = (i,)
    if reader.loadObjId:
        rec = reader.readIdRec()
        idRec += rec[3:5]
    
    parRec = reader.readParRec()
    if parRec is None:
        break
    tPar.append([idRec + parRec])

    synRec = reader.readSynRec()
    if synRec is None:
        break
    tSyn.append([idRec + synRec])

    elRecs = reader.readElineRec()
    if elRecs is None:
        break
    for r in elRecs:
        tEl.append([idRec + r])

tSyn.flush()
tPar.flush()
tEl.flush()
nRecords = i + 1
dt = time.time() - t1
dndt = nRecords / dt

t1 = time.time()
print 'Creating default indices, may take a while...'
tSyn.cols.index.createCSIndex(filters=createFilter())
tPar.cols.index.createCSIndex(filters=createFilter())
tEl.cols.index.createCSIndex(filters=createFilter())
tPar.cols.aid.createCSIndex(filters=createFilter())
tEl.cols.lineId.createCSIndex(filters=createFilter())
if reader.loadObjId:
    print 'Creating objId indices, may take a while...'
    tSyn.cols.specObjId.createCSIndex(filters=createFilter())
    tSyn.cols.objId.createCSIndex(filters=createFilter())
    tPar.cols.specObjId.createCSIndex(filters=createFilter())
    tPar.cols.objId.createCSIndex(filters=createFilter())
    tEl.cols.specObjId.createCSIndex(filters=createFilter())
    tEl.cols.objId.createCSIndex(filters=createFilter())
if args.extraIndex:
    print 'Creating extra physical indices, may take a while...'
    tPar.cols.z.createCSIndex(filters=createFilter())
    tSyn.cols.Mcor_gal.createCSIndex(filters=createFilter())
    tEl.cols.EW.createCSIndex(filters=createFilter())
    tEl.cols.flux.createCSIndex(filters=createFilter())
    tEl.cols.SN.createCSIndex(filters=createFilter())

idt = time.time() - t1

reader.close()
db.close()

print 'Total: %i records in %.2f seconds (dn/dt = %.2f).' % (nRecords, dt, dndt)
print 'Time to create indices: %.2f seconds.' % idt
