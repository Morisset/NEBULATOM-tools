'''
Created on May 28, 2013

@author: andre
'''
from os import path
from file_reader import TextFileReader, FixedTextFileReader

################################################################################
parFields = ['aid', 'plate', 'mjd', 'fiber', 'ra', 'dec', 'z', 'eClass',
             'm_u', 'm_g', 'm_r', 'm_i', 'm_z',
             'fm_u', 'fm_g', 'fm_r', 'fm_i', 'fm_z',
             'Mu', 'Mg', 'Mr', 'Mi', 'Mz',
             'SB_50_r', 'CI_r', 'petrorad_r', 'petroR50_r', 'petroR90_r',
             'expAB_r', 'deVAB_r', 'D', 'DA', 'R50', 'R90', 'DL', 'log_L',
             'Mr_fiber', 'log_L_fiber', 'Mz_fiber', 'log_L_fiber_z',
             'petrorad_z', 'petroR50_z', 'petroR90_z', 'DA_z', 'R50_z', 'R90_z', 'flag_duplicate']
parTypes = ['S14', 'int32', 'int32', 'int32', 'float32', 'float32', 'float32', 'float32',
            'float32', 'float32', 'float32', 'float32', 'float32',
            'float32', 'float32', 'float32', 'float32', 'float32',
            'float32', 'float32', 'float32', 'float32', 'float32',
            'float32', 'float32', 'float32', 'float32', 'float32',
            'float32', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
            'float32', 'float32', 'float32', 'float32',
            'float32', 'float32', 'float32', 'float32', 'float32', 'float32', 'int32']
################################################################################


################################################################################
objIdFields = ['plate', 'mjd', 'fiber', 'objId', 'specObjId']
objIdTypes = ['int32', 'int32', 'int32', 'int64', 'int64']
################################################################################


################################################################################
syn01Fields = ['syn_file', 'x_PL', 'x_Y', 'x_I', 'x_O', 'mu_Y', 'mu_I', 'mu_O',
               'A_V', 'v0', 'vd', 'chi2', 'adev', 'SN_w', 'SN_n', 'OSN_w', 'OSN_n', 'Nn0', 'NOl_eff', 'Nl_eff']
syn01Types = ['S32', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32', 'int32', 'int32', 'int32']

syn02Fields = ['syn_file', 'at_flux', 'at_mass', 'aZ_flux', 'aZ_mass', 'am_flux', 'am_mass',
               'st_flux', 'st_mass', 'sZ_flux', 'sZ_mass', 'sm_flux', 'sm_mass',
               'i_boc', 'boc_age', 'boc_Z', 'boc_chi2', 'boc_adev', 'boc_AV']
syn02Types = ['S20', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32']

syn03Fields = ['syn_file', 'M2L_u', 'M2L_g', 'M2L_r', 'M2L_i', 'M2L_z', 'M2L_B', 'M2L_V', 'M2L_BOL']
syn03Types = ['S20', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32']

syn04Fields = ['syn_file', 'Mcor_fib', 'Mini_fib', 'Mret_fib', 'Mcor_gal', 'Mini_gal', 'Mret_gal',
               'Den_Mcor', 'Den_Mini', 'Mpho_gal', 'fobs_norm', 'Flux_tot', 'log_Lnorm', 'log_Ltot',
               'z', 'DL_Mpc', 'FibCor', 'HLR_kpc', 'Mz_gal', 'tz_lookback']
syn04Types = ['S20', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32']

# Build the whole synthesis fields removing the duplicate 'syn_file' entries.
synFields = syn01Fields + syn02Fields[1:] + syn03Fields[1:] + syn04Fields[1:]
synTypes = syn01Types + syn02Types[1:] + syn03Types[1:] + syn04Types[1:]
################################################################################


################################################################################
cfgElFields = ['lineId', 'name', 'wl_central', 'wl_low_blue_con', 'wl_upp_blue_con', 'wl_low_red_con', 'wl_upp_red_con']
cfgElTypes = ['int32', 'S16', 'float32', 'float32', 'float32', 'float32', 'float32']
################################################################################


################################################################################
elFieldsRaw = ['syn_file',
               'flux_3727', 'sigflux_3727', 'EW_3727', 'sigEW_3727', 'vd_3727', 'sigvd_3727',
               'v0_3727', 'sigv0_3727', 'SN_3727', 'fc_3727', 'sigfc_3727',
               'flux_3869', 'sigflux_3869', 'EW_3869', 'sigEW_3869', 'vd_3869', 'sigvd_3869',
               'v0_3869', 'sigv0_3869', 'SN_3869', 'fc_3869', 'sigfc_3869',
               'flux_4101', 'sigflux_4101', 'EW_4101', 'sigEW_4101', 'vd_4101', 'sigvd_4101',
               'v0_4101', 'sigv0_4101', 'SN_4101', 'fc_4101', 'sigfc_4101',
               'flux_4340', 'sigflux_4340', 'EW_4340', 'sigEW_4340', 'vd_4340', 'sigvd_4340',
               'v0_4340', 'sigv0_4340', 'SN_4340', 'fc_4340', 'sigfc_4340',
               'flux_4363', 'sigflux_4363', 'EW_4363', 'sigEW_4363', 'vd_4363', 'sigvd_4363',
               'v0_4363', 'sigv0_4363', 'SN_4363', 'fc_4363', 'sigfc_4363',
               'flux_4861', 'sigflux_4861', 'EW_4861', 'sigEW_4861', 'vd_4861', 'sigvd_4861',
               'v0_4861', 'sigv0_4861', 'SN_4861', 'fc_4861', 'sigfc_4861',
               'flux_4959', 'sigflux_4959', 'EW_4959', 'sigEW_4959', 'vd_4959', 'sigvd_4959',
               'v0_4959', 'sigv0_4959', 'SN_4959', 'fc_4959', 'sigfc_4959',
               'flux_5007', 'sigflux_5007', 'EW_5007', 'sigEW_5007', 'vd_5007', 'sigvd_5007',
               'v0_5007', 'sigv0_5007', 'SN_5007', 'fc_5007', 'sigfc_5007',
               'flux_6300', 'sigflux_6300', 'EW_6300', 'sigEW_6300', 'vd_6300', 'sigvd_6300',
               'v0_6300', 'sigv0_6300', 'SN_6300', 'fc_6300', 'sigfc_6300',
               'flux_6548', 'sigflux_6548', 'EW_6548', 'sigEW_6548', 'vd_6548', 'sigvd_6548',
               'v0_6548', 'sigv0_6548', 'SN_6548', 'fc_6548', 'sigfc_6548',
               'flux_6563', 'sigflux_6563', 'EW_6563', 'sigEW_6563', 'vd_6563', 'sigvd_6563',
               'v0_6563', 'sigv0_6563', 'SN_6563', 'fc_6563', 'sigfc_6563',
               'flux_6584', 'sigflux_6584', 'EW_6584', 'sigEW_6584', 'vd_6584', 'sigvd_6584',
               'v0_6584', 'sigv0_6584', 'SN_6584', 'fc_6584', 'sigfc_6584',
               'flux_6717', 'sigflux_6717', 'EW_6717', 'sigEW_6717', 'vd_6717', 'sigvd_6717',
               'v0_6717', 'sigv0_6717', 'SN_6717', 'fc_6717', 'sigfc_6717',
               'flux_6731', 'sigflux_6731', 'EW_6731', 'sigEW_6731', 'vd_6731', 'sigvd_6731',
               'v0_6731', 'sigv0_6731', 'SN_6731', 'fc_6731', 'sigfc_6731',
               'flux_4471', 'sigflux_4471', 'EW_4471', 'sigEW_4471', 'vd_4471', 'sigvd_4471',
               'v0_4471', 'sigv0_4471', 'SN_4471', 'fc_4471', 'sigfc_4471']

elFieldSizes = [14,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10,
                10, 10, 10, 10, 10, 10,
                10, 10, 10, 10, 10]

elTypesRaw = ['S20',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32', 'float32',
              'float32', 'float32', 'float32', 'float32', 'float32']

elIndex = []
for db in elFieldsRaw:
    if db.startswith('flux'):
        elIndex.append(int(db.split('_')[1]))

_elFields = ['flux', 'sigflux', 'EW', 'sigEW', 'vd', 'sigvd',
             'v0', 'sigv0', 'SN', 'fc', 'sigfc']
_elTypes = ['float32', 'float32', 'float32', 'float32', 'float32', 'float32',
            'float32', 'float32', 'float32', 'float32', 'float32']

elFields = ['lineId'] + _elFields
elTypes = ['int32'] + _elTypes

################################################################################


################################################################################
syn01FileName = 'sample.FDR7.926246.f.Starlight.SYN01.tab.BS'
syn02FileName = 'sample.FDR7.926246.f.Starlight.SYN02.tab.BS'
syn03FileName = 'sample.FDR7.926246.f.Starlight.SYN03.tab.BS'
syn04FileName  = 'sample.FDR7.926246.f.Starlight.SYN04.tab.BS'
parFileName = 'sample.FDR7.926246.f.parameters.dat'
elFileName = 'sample.FDR7.926246.f.lines.dat.BS'
cfgElFileName = 'sample.FDR7.926246.f.cfg-lines.dat'
objIdFileName = 'sample.FDR7.926246.f.objid.dat'

class SynthesisReader(object):
    def __init__(self, dirName):
        self._parFile = TextFileReader(path.join(dirName, parFileName), parFields, parTypes)
        self._elFile = FixedTextFileReader(path.join(dirName, elFileName), elFieldsRaw, elFieldSizes, elTypesRaw)
        self._syn01File = TextFileReader(path.join(dirName, syn01FileName), syn01Fields, syn01Types)
        self._syn02File = TextFileReader(path.join(dirName, syn02FileName), syn02Fields, syn02Types)
        self._syn03File = TextFileReader(path.join(dirName, syn03FileName), syn03Fields, syn03Types)
        self._syn04File = TextFileReader(path.join(dirName, syn04FileName), syn04Fields, syn04Types)

        objIdPath = path.join(dirName, objIdFileName)
        self.loadObjId = path.exists(objIdPath)
        if self.loadObjId:
            print 'loading objID from %s.' % objIdPath
            self._objIdFile = TextFileReader(objIdPath, objIdFields, objIdTypes)

        cfgElPath = path.join(dirName, cfgElFileName)
        self.loadCfgEline = path.exists(cfgElPath)
        if self.loadCfgEline:
            print 'loading elines config from %s.' % cfgElPath
            self._cfgElFile = TextFileReader(cfgElPath, cfgElFields, cfgElTypes)


    def elinesPerRec(self):
        return len(elIndex)
    
    
    def readCfgElineRec(self):
        return self._cfgElFile.readRec()

        
    def readElineRec(self):
        elinesRaw = self._elFile.readDict()
        
        elines = []
        for idx in elIndex:
        # TODO: find undetected lines
            el = []
            el.append(idx)
            for prefix in _elFields:
                el.append(elinesRaw['%s_%s' % (prefix, idx)])
            elines.append(tuple(el))
        return elines


    def readIdRec(self):
        return self._objIdFile.readRec()


    def readSynRec(self):
        # Merge synthesis data removing redundant 'arq_syn' fields.
        synthesis = self._syn01File.readRec()
        if synthesis is None:
            return None
        synthesis += self._syn02File.readRec()[1:]
        synthesis += self._syn03File.readRec()[1:]
        synthesis += self._syn04File.readRec()[1:]
        return synthesis
    

    def readParRec(self):
        return self._parFile.readRec()


    def close(self):
        self._parFile.close()
        self._elFile.close()
        self._syn01File.close()
        self._syn02File.close()
        self._syn03File.close()
        self._syn04File.close()
        if self.loadCfgEline:
            self._cfgElFile.close()
        if self.loadObjId:
            self._objIdFile.close()

################################################################################
        
