'''
Created on Aug 22, 2012

@author: andre
'''

import argparse
from pystarlight.util.gridfile import GridFile
import hashlib
import vos
import tarfile
from os import path, mkdir, listdir, unlink
import subprocess
from shutil import rmtree

stagingDir = '.'

def getMD5(filename):
    md5=hashlib.md5()
    fin = file(filename,'r')
    while True:
        buff=fin.read()
        if len(buff)==0:
            break
        md5.update(buff)
    return md5.hexdigest()

###############################################################################

def VOSDownload(src, dest, force=False):
    cl = vos.Client()
    if not force and path.exists(dest):
        remMD5 = cl.getNode(src).props.get('MD5', '')
        if remMD5 == getMD5(dest):
            print 'Skipping download of %s' % src
            return
    cl.copy(src, dest)

###############################################################################

def VOSUpload(src, dest, force=False):
    cl = vos.Client()
    if not force:
        try:
            remMD5 = cl.getNode(dest).props.get('MD5', '')
        except:
            remMD5 = ''
        if remMD5 == getMD5(src):
            print 'Skipping upload of %s' % src
            return
    cl.copy(src, dest)

###############################################################################

def downloadIfRemote(src, force):
    '''
    If the file at src is not local, download it into stagingDir
    and return the local path to the file. Only VOSpace available ATM.
    '''
    if not src.startswith('vos:'):
        return src
    srcHere = path.join(stagingDir, path.basename(src))
    VOSDownload(src, srcHere, force)
    return srcHere

###############################################################################

def extractTarball(src, dest, forceDownload):
    src = downloadIfRemote(src, forceDownload)
    tar = tarfile.open(src)
    if not path.exists(dest):
        mkdir(dest)
    tar.extractall(dest)
    tar.close()
    
###############################################################################

def createTarball(dest, files):
    tar = tarfile.open(dest, 'w:bz2')
    for f in files:
        tar.add(f, arcname=path.basename(f))
    tar.close()
    
###############################################################################
    
def getLuminDistMap(masterList, force):
    import atpy
    import asciitable
    masterList = downloadIfRemote(masterList, force)
    # FIXME: The master list has columns with same name.
    mlTable = atpy.Table(masterList, type='ascii', delimiter=',', Reader=asciitable.CommentedHeaderReader)    
    return dict(zip(mlTable.CALIFA_ID.tolist(), mlTable.d_Mpc.tolist()))

###############################################################################

def runStarlight(starlightPath, cwd, input):
    slProc = subprocess.Popen(starlightPath, cwd=stagingDir, stdin=subprocess.PIPE)
    slProc.communicate(input)
    return slProc.wait()

###############################################################################

def runOutputChecker(checkerPath, outDir, outFiles):
    '''
    The input and output of the checker is a mess, so is this code.
    I refrain from commentaries.
    '''
    input = '%d \'%s\'\n' % (len(outFiles), outDir) + '\n'.join(outFiles) + '\n'
    slProc = subprocess.Popen(checkerPath, cwd=stagingDir,
                              stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    result = slProc.communicate(input)
    slProc.wait()
    
    result = result[0].split('\n')
    result.pop();result.pop()
    okFiles = []
    badFiles = []
    for x in result:
        x = x.split()
        if x[2] == 'Ok!':
            okFiles.append(path.basename(x[0]))
        else:
            badFiles.append(path.basename(x[0]))
    return okFiles, badFiles

###############################################################################

parser = argparse.ArgumentParser(description='Run STARLIGHT for input files in tarball.',
                                 fromfile_prefix_chars='@')
parser.add_argument('specFile', type=str, nargs=1, help='tarball file containing input spectra.')
parser.add_argument('--master-list', dest='masterList', default='vos:streeto/califa_master_list_rgb.txt',
                    help='Path to CALIFA master list.')
parser.add_argument('--config-file', dest='configFile', default='vos:streeto/config.tar.bz2',
                    help='Path to config files tarball.')
parser.add_argument('--staging-dir', dest='stagingDir', default='.',
                    help='Staging dir, where to save temporary stuff.')
parser.add_argument('--base-file', dest='baseFile', default='vos:streeto/basesDir.tar.bz2',
                    help='STARLIGHT base tarball.')
parser.add_argument('--force-download', dest='forceDownload', action='store_true',
                    help='Force download of files stored in VOSpace.')
parser.add_argument('--suffix', dest='suffix', default='v01',
                    help='Suffix to append to output files.')
parser.add_argument('--starlight', dest='starlightCmd', default='starlight',
                    help='path to STARLIGHT command.')
parser.add_argument('--checker', dest='checkerCmd', default='checker',
                    help='path to STARLIGHT output checker command.')
parser.add_argument('--rand-phone', dest='randPhone', type=int, default=0,
                    help='Random seed.')

###############################################################################

args = parser.parse_args()
stagingDir = path.abspath(args.stagingDir)

specFile = args.specFile[0]
specFileDir = path.join(stagingDir, 'sl_in')
if path.exists(specFileDir):
    rmtree(specFileDir)
mkdir(specFileDir)
extractTarball(specFile, specFileDir, args.forceDownload)

outDir = path.join(stagingDir, 'sl_out')
if not path.exists(outDir):
    mkdir(outDir)
 
basesDir = path.join(stagingDir, 'basesDir')
if not path.exists(basesDir):
    print 'Bases directory does not exist, downloading...'
    extractTarball(args.baseFile, basesDir, args.forceDownload)
    
extractTarball(args.configFile, stagingDir, args.forceDownload)
 
distMap = getLuminDistMap(args.masterList, args.forceDownload)

grid = GridFile()
gridTemplateFile = path.join(stagingDir, 'grid.template.in')
grid.loadFrom(gridTemplateFile)
if args.randPhone <> 0:
    grid.randPhone = args.randPhone
else:
    grid.seed()
grid.basesDir = basesDir + path.sep
grid.obsDir = specFileDir + path.sep
grid.maskDir = stagingDir + path.sep
grid.etcDir = stagingDir + path.sep
grid.outDir = outDir + path.sep

runTemplate = grid.runs.pop()

for f in listdir(specFileDir):
    f = path.basename(f)
    califaID = f[:5]
    newRun = runTemplate.clone()
    newRun.inFile = f
    newRun.outFile = '%s.%s.%s' % (f, newRun.baseFile, args.suffix)
    newRun.lumDistanceMpc = distMap[califaID]
    grid.runs.append(newRun)

its = 0
finishedOutput = []
while len(grid.runs) > 0 and its < 10:
    its += 1
    gridData = grid.render()
    result = runStarlight(args.starlightCmd, stagingDir, gridData)
    if result <> 0:
        print 'Whoops, starlight failed.'
        continue
    outFiles = [path.basename(f) for f in listdir(grid.outDir)]
    okFiles, badFiles = runOutputChecker(args.checkerCmd, grid.outDir, outFiles)
    finishedOutput.extend(okFiles)
    grid.runs = [x for x in grid.runs if x.outFile not in okFiles]
    for f in badFiles:
        print 'Removing corrupt output: %s' % f
        unlink(path.join(outDir, f))

if its >= 10:
    print 'Bailed without finishing the job, check the parameters.'

print  'finished ouputs: %d' % len(finishedOutput)
localOutFilePath = path.join(stagingDir, 'output.' + path.basename(specFile))
outFilePath = path.join(path.dirname(specFile), 'output.' + path.basename(specFile))
createTarball(localOutFilePath, [path.join(grid.outDir, x) for x in finishedOutput])
VOSUpload(localOutFilePath, outFilePath)
